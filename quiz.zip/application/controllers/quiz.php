<?php
class Quiz extends CI_Controller
{
	public function add_quiz()
	{
		$quiz_title=$this->input->post('quiz_title');
		$ques=$this->input->post('ques');
		$users=$this->input->post('users');
		$min_percentage=$this->input->post('min_percentage');
		$noques=count($ques);
		$time=$noques*2;
		$date=date('Y-m-d');
		
		//array to store all data into single array//
		$options_arry=array();
		$answer_arry=array();
		$type_arry=array();
		
		for($no=1;$no<=$noques;$no++)
		{		
			$opt_type_id='option_type_'.$no;
			$option_id='ques_'.$no.'_opt';
			$ans_id='ques_'.$no.'_ans';
			$type=$this->input->post($opt_type_id);
			$option=$this->input->post($option_id);
			$ans=$this->input->post($ans_id);
			//stored all data into single inner array with its associates//
			$options_arry[$no-1]=$option;
			$answer_arry[$no-1]=$ans;
			$type_arry[$no-1]=$type;
			
		}
		//converting all array to json-serialization//
		$questions_json=json_encode($ques);
		$options_json=json_encode($options_arry);
		$type_json=json_encode($type_arry);
		$answer_json=json_encode($answer_arry);
		
		$data=array('title'=>$quiz_title,'questions'=>$questions_json,'min_percentage'=>$min_percentage,'type'=>$type_json,'options'=>$options_json,'answers'=>$answer_json,'date'=>$date,'duration'=>$time,'no_of_users'=>$users);
		$this->load->model('test');
		$res=$this->test->add_quiz($data);
		$this->session->set_flashdata('success','Added Successfully');
		redirect('admin_home/manage_quiz');
	}
	
	public function delete_quiz()
	{
		$id=$_REQUEST['id'];
		$this->load->model('test');
		$res=$this->test->delete($id);
		if ($res==1)
		{
		$this->session->set_flashdata('success','Deleted Successfully');
		}
		redirect('admin_home/manage_quiz');
	}
	
	public function edit_quiz()
	{
		$quiz_title=$this->input->post('quiz_title');
		$quiz_id=$this->input->post('test_id');
		$ques=$this->input->post('ques');
		$users=$this->input->post('users');
		$min_percentage=$this->input->post('min_percentage');
		$noques=count($ques);
		$time=$noques*2;
		$date=date('Y-m-d');
		
		//array to store all data into single array//
		$options_arry=array();
		$answer_arry=array();
		$type_arry=array();
		
		for($no=1;$no<=$noques;$no++)
		{		
			$opt_type_id='option_type_'.$no;
			$option_id='ques_'.$no.'_opt';
			$ans_id='ques_'.$no.'_ans';
			$type=$this->input->post($opt_type_id);
			$option=$this->input->post($option_id);
			$ans=$this->input->post($ans_id);
			//stored all data into single inner array with its associates//
			$options_arry[$no-1]=$option;
			$answer_arry[$no-1]=$ans;
			$type_arry[$no-1]=$type;
			
		}
		//converting all array to json-serialization//
		$questions_json=json_encode($ques);
		$options_json=json_encode($options_arry);
		$type_json=json_encode($type_arry);
		$answer_json=json_encode($answer_arry);
		
		$data=array('title'=>$quiz_title,'questions'=>$questions_json,'min_percentage'=>$min_percentage,'type'=>$type_json,'options'=>$options_json,'answers'=>$answer_json,'date'=>$date,'duration'=>$time,'no_of_users'=>$users);
		$this->load->model('test');
		$res=$this->test->edit_test($data,$quiz_id);
		$this->session->set_flashdata('success','Updated Successfully');
		redirect('admin_home/manage_quiz');
	}
	public function quiz_validate()
	{
		$user_id= $this->input->post('user_id');
		$test_id=$this->input->post('test_id');
		$ques_count=$this->input->post('ques_count');
		$answer_arry=array();
		for($no=1;$no<=$ques_count;$no++)
		{
			$ans_id='ques_'.$no.'_ans';
			$ans=$this->input->post($ans_id);
			$answer_arry[$no-1]=$ans;
		}
		$this->load->model('test');
		$correct_answer=$this->test->get_test_hall($test_id);
		$marks=0;
		foreach($correct_answer as $row)
			{
				$answer=$row['answers'];
				$answer=json_decode($answer);
				
			}
		for($i=0;$i<count($answer);$i++)
		{
			$qno=$i+1;
			if($answer[$i]==$answer_arry[$i])
			{
				// echo '<br>';
				// echo $qno.'- Correct';
				$marks+=1;
				// echo '<br>';
			}
			else
			{
				// echo '<br>';
				// echo $qno.'- Incorrect <br>The correct answer is :';
				// foreach ($answer[$i] as $rows1)
				// {
					// echo '<br>'.$rows1;
				// }
				// echo '<br>';
			}
		}
		
		
		$percentage= $marks/count($answer)*100;
		$percentage=number_format((float)$percentage, 2, '.', '');
		$answer_arry=json_encode($answer_arry);
		$data=array('user_id'=>$user_id,'test_id'=>$test_id,'user_answers'=>$answer_arry,'correct_answers'=>$marks,'percentge'=>$percentage);
		$this->load->model('test');
		$res=$this->test->result($data);
		if($res)
		{
			$this->session->set_flashdata('success','You have completed the Exam Successfully');
		}
		$data1['answers']=$data;
		$data1['correct_answer']=$answer;
		$data1['id']=$res;
		$this->load->view('user/header');
		$this->load->view('user/result',$data1);
		$this->load->view('user/footer');
		
	}
	public function save_certificate()
	{
		$c_name = $_REQUEST['c_name'];
		$res_id=$_REQUEST['id'];
		$this->load->model('test');
		$res=$this->test->update_certificate($c_name, $res_id);
		if($res==1)
			{
				echo"";
			}
		else
			{
				echo "Certificate Can't be Generated";
			}
	}
	public function mail_certificate()
	{
		$this->load->library('email');
		$config['protocol']  = 'smtp';
		$config['smtp_host'] = 'smtp.openwavecomp.in';
		$config['smtp_port'] = 25;
		$config['smtp_timeout'] = 30;
		$config['smtp_user'] = 'admin@openwavecomp.in';
		$config['smtp_pass'] = 'Sterling#2010';
		$config['mailtype']  = 'html';
		$config['charset']  = 'utf-8';
		$config['wordwrap']  = TRUE;
		$config['newline']  = '\r\n';
		$this->email->initialize($config);
		$email_from="admin@openwavecomp.in";
		$email_to=$this->session->userdata('email');
		$f_name=$this->session->userdata('first_name');
		$l_name=$this->session->userdata('last_name');
		$user_name=$f_name.' '.$l_name;
		$certi=$_REQUEST['c_name'];
		$data= array('user_name'=>$user_name,'email'=>$email_to,'certi'=>$certi);
		$email_subject="Certificates";
		$msg= $this->load->view('user/email_template',$data,TRUE);
		$this->email->from($email_from, 'test');
		$this->email->to($email_to);
		$this->email->subject($email_subject);
		$this->email->message($msg);
		$this->email->attach(base_url().'assets/certificates/'.$certi);
		if($this->email->send())
		{
			
			echo 'mail has Sent';
		}
		else
		{
			
			echo 'mail can\'t be Sent';
		}
	}
	
	public function timings()
	{
		$min=$_REQUEST['min'];
		$sec=$_REQUEST['sec'];
		$id=$_REQUEST['id'];
		$time= array('min'=>$min,'sec'=>$sec,'time_id'=>$id);
		$this->session->set_userdata($time);
		
		
	}
	
}
?>