<?php
class Admin_home extends CI_Controller
{
public function __construct()
{
		parent::__construct();
		if(!$this->session->userdata('admin_email'))
			{
				redirect('index/show');
			}
		$this->load->model('Admin_model');
		$this->load->library('encrypt');
}
public function home()
{
	$this->load->view('admin/header.php');
	$data['admin_num']=$this->Admin_model->admin_num();
	$data['admin']=$this->Admin_model->admin_details();
	$data['users_num']=$this->Admin_model->user_count();
	$this->load->model('test');
	$data['quiz_list']=$this->test->get_test();
	$data['quiz_num']=$this->test->get_test_num();
	$this->load->view('admin/home.php',$data);
	$this->load->view('admin/footer.php');
}
//Administrator
public function create_admin()
{
	$this->load->view('admin/header.php');
	$this->load->view('admin/create_admin.php');
	$this->load->view('admin/footer.php');
}

public function admin_view()
{
	$this->load->view('admin/header.php');
	$data['admin']=$this->Admin_model->admin_details();
	$this->load->view('admin/admin_view.php',$data);
	$this->load->view('admin/footer.php');
}

public function check_mail()
{
	$email=$_REQUEST['email'];
	$res=$this->Admin_model->check_mail($email);
	echo $res;
}


public function add_admin()
{
	$this->form_validation->set_rules('email','Email','required|trim|valid_email');
	$this->form_validation->set_rules('fname','First Name','required|trim|alpha');
	$this->form_validation->set_rules('name','Name','required|trim|alpha');
	$this->form_validation->set_rules('password','Password','required|trim|min_length[8]');
	$this->form_validation->set_rules('conf_password','Confirm Password','required|trim|matches[password]');
	if($this->form_validation->run()==FALSE)
	{   
		$this->session->error="1";
		$this->session->mark_as_flash('error');
		$this->create_admin();
	}
	else
	{
		$email=$this->input->post('email');
		$fname=$this->input->post('fname');
		$lname=$this->input->post('lname');
		$name=$this->input->post('name');
		$password=md5($this->input->post('password'));
		$data=array('id'=>"",'first_name'=>$fname,'last_name'=>$lname,'user_name'=>$name,'email'=>$email,'password'=>$password);
			$res=$this->Admin_model->insert($data);
		if($res>0)
		{
		$this->session->set_flashdata('success','Registred Successfully');
		}
		else
		{
		$this->session->set_flashdata('success','Registred Unsuccessfully');
		}
		$this->admin_view();
	}

}

public function edit_admin()
{
	$id=$this->input->get('id');
	$data['details']=$this->Admin_model->get_details($id);
	$this->load->view('admin/header.php');
	$this->load->view('admin/edit_admin.php',$data);
	$this->load->view('admin/footer.php');
}

public function update_admin()
{
	$this->form_validation->set_rules('uname','Name','required|trim|alpha');
	$this->form_validation->set_rules('fname','Name','required|trim|alpha');
	$this->form_validation->set_rules('lname','Name','trim|alpha');
	if($this->form_validation->run()==FALSE)
		{   
		$this->session->error="1";
		$this->session->mark_as_flash('error');
		$this->edit_admin();
		}
	else
		{
		$id=$this->input->post('id');
		$email=$this->input->post('email');
		$fname=$this->input->post('fname');
		$lname=$this->input->post('lname');
		$uname=$this->input->post('uname');
		$data=array('id'=>$id,'email'=>$email,'first_name'=>$fname,'last_name'=>$lname,'user_name'=>$uname);
		$result=$this->Admin_model->update($data);
		if ($result==1)
			{
			$this->session->set_flashdata('updated','Updated Successfully.');
			}

		redirect('admin_home/admin_view');
		}
}

public function delete_admin()
{
	$id=$_GET['id'];
	$result=$this->Admin_model->delete($id);
	if($result==1)
		{
				$this->session->set_flashdata('deleted','Successfully.');
		}
	redirect('admin_home/admin_view');
}


//Administrator

//Users
public function view_users()
{
	$data['user_details']=$this->Admin_model->user_details();
	$this->load->view('admin/header.php');
	$this->load->view('admin/view_user.php',$data);
	$this->load->view('admin/footer.php');
}


public function remove_users()
{
	$this->form_validation->set_rules('delete','Delete','required');
	if($this->form_validation->run()==FALSE)
	{   
		$this->session->error="1";
		$this->session->mark_as_flash('error');
		$this->view_users();
	}
	else
		{
		//update values for the admin and redirect to home page 
			redirect('admin_home/home');
		}
	}
//Users


//Quiz

public function add_quiz()
	{
		$this->load->view('admin/header.php');
		$this->load->view('admin/add_quiz.php');
		$this->load->view('admin/footer.php');
	}

public function manage_quiz()
{
	$this->load->model('test');
	$data['test']=$this->test->get_test();
	$this->load->view('admin/header.php');
	$this->load->view('admin/manage_quiz.php',$data);
	$this->load->view('admin/footer.php');
}

public function edit_quiz()
{
	$id=$_REQUEST['id'];
	$this->load->model('test');
	$data['edit']=$this->test->get_test_id($id);
	$this->load->view('admin/header.php');
	$this->load->view('admin/edit_quiz.php',$data);
	$this->load->view('admin/footer.php');
}

//Quiz


//certificate

public function certificate()
{
	$this->load->view('admin/header.php');
	$this->load->view('admin/certificate.php');
	$this->load->view('admin/footer.php');
}

//certificate



//account settings

public function profile()
{
	$this->load->view('admin/header.php');
	$id=$this->session->userdata('admin_id');
	$data['details']=$this->Admin_model->get_details($id);
	$this->load->view('admin/profile.php',$data);
	$this->load->view('admin/footer.php');
}

public function change_password()
{
	$this->load->view('admin/header.php');
	$this->load->view('admin/change_password.php');
	$this->load->view('admin/footer.php');
}

public function set_password()
{
	$this->form_validation->set_rules('old_pass','Old Password','required|min_length[8]');
	$this->form_validation->set_rules('new_pass','New Password','required|min_length[8]');
	$this->form_validation->set_rules('conf_pass','Confirm Password','required|min_length[8]|matches[new_pass]');
	if($this->form_validation->run()==TRUE)
	{
		$id=$this->session->userdata['admin_id'];
		$old_pass=md5($this->input->post('old_pass'));
		$new_pass=md5($this->input->post('new_pass'));
		$conf_pass=$this->input->post('conf_pass');
		$data=array('old_pass'=>$old_pass,'id'=>$id,'new'=>$new_pass);
		$res=$this->Admin_model->change_password($data);
		if($res==1)
		{
			$data1=array('password'=>$new_pass);
			$res1=$this->Admin_model->change_password1($data1,$id);
			if($res1)
				{
					$this->session->set_flashdata('change_pass','Password Changed Successfully');
					redirect('admin_home/change_password');
				}
			else
				{
					$this->session->set_flashdata('change_pass','Incorect Old password');
					redirect('admin_home/change_password');
				}
		}
		// $res=$this->Admin_model->change_password($data);
		// if(!empty($res))
		// {
			// if($res[0]['password'] == $old_pass)
				// {
						// $data1=array('password'=>$new_pass);
					// $res1=$this->Admin_model->change_password1($data1,$id);
					// if($res1)
					// {
						// $this->session->set_flashdata('change_pass',$res1);
						// redirect('admin_home/change_password');
					// }
				// }
				// else
				// {
						
						// redirect('admin_home/change_password');
				// }
		// }
	}
	else
	{
		$this->load->view('admin/header.php');
		$this->load->view('admin/change_password.php');
		$this->load->view('admin/footer.php');
	}
}


//account settings

}

?>