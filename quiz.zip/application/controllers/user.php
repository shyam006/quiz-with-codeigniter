<?php
Class user extends CI_Controller
{
 function __construct() 
 {
	parent::__construct();
	$this->load->model('user_model');
	
		
}
public function check_mail()
	{
		$email=$_REQUEST['email'];
		$res=$this->user_model->check_mail($email);
		echo $res;
	}


public function user_home()
{
	$this->load->view('user/head_before_login');
	$this->load->view('user/index');
	$this->load->view('user/footer');
}

public function user_technology()
{
	$this->load->view('user/head_before_login');
	$this->load->view('user/technology');
	$this->load->view('user/footer');
}

public function user_about()
{
	$this->load->view('user/head_before_login');
	$this->load->view('user/about');
	$this->load->view('user/footer');
}

public function user_blog()
{
	$this->load->view('user/head_before_login');
	$this->load->view('user/blog');
	$this->load->view('user/footer');
}

public function user_contact()
{
	$this->load->view('user/head_before_login');
	$this->load->view('user/contact');
	$this->load->view('user/footer');
}

public function user_login()
{
	$this->load->view('user/head_before_login');
	$this->load->view('user/login');
	$this->load->view('user/footer');
}

public function user_register()
{
	$this->load->view('user/head_before_login');
	$this->load->view('user/register');
	$this->load->view('user/footer');
}

public function check_user()
{
$this->form_validation->set_rules('email','Email','required|valid_email|trim');
$this->form_validation->set_rules('first_name','First Name','required|trim|min_length[4]|alpha');
$this->form_validation->set_rules('date','Date of Birth','required');
$this->form_validation->set_rules('password','Password','required|min_length[5]');
$this->form_validation->set_rules('conf_password','Confirm Password','required|matches[password]');
	if($this->form_validation->run()==TRUE)
	{
	
		$email=$this->input->post('email');
		$first_name=$this->input->post('first_name');
		$last_name=$this->input->post('last_name');
		$dob=$this->input->post('date');
		$password=md5($this->input->post('password'));
		$data=array('email'=>$email,'first_name'=>$first_name,'last_name'=>$last_name,'dob'=>$dob,'password'=>$password);
		$this->load->model('user_model');
		$res=$this->user_model->add_user($data);
		if($res==1)
		{
			$this->session->set_flashdata('register',$res);
			redirect('user/user_login');
		}
		
	}
		
	else
	{
		$this->load->view('user/head_before_login');
		$this->load->view('user/register');
		$this->load->view('user/footer');
	}
}

public function check_login()
	{
		$this->form_validation->set_rules('email','Email','required|trim|valid_email');
		$this->form_validation->set_rules('password','Password','required|min_length[8]');
		if($this->form_validation->run()==TRUE)
			{
				$email=$this->input->post('email');
				$password=$this->input->post('password');
				$data=array('email'=>$email,'password'=>$password);
				$res=$this->user_model->check_login($data);
				if(!empty($res))
				{
					foreach ($res as $row)  
						{
							$first_name=$row['first_name'];
							$last_name=$row['last_name'];
							$email=$row['email'];
							$id=$row['id'];
						}
						
					$loggedin=array('first_name'=>$first_name,'last_name'=>$last_name,'email'=>$email,'id'=>$id);
					$this->session->set_userdata($loggedin);
					redirect('Logged_users/home');
				}
				else
				{
					$data="Incorrect Email or Password";
					$this->session->set_flashdata('error',$data);
					$this->load->view('user/head_before_login');
					$this->load->view('user/login');
					$this->load->view('user/footer');
				}
			}
		else
			{
				$this->load->view('user/head_before_login');
				$this->load->view('user/login');
				$this->load->view('user/footer');
			}
	}
	

public function user_logout()
	{
		$this->session->sess_destroy();
		redirect('user/user_home');
	}	








}

?>










