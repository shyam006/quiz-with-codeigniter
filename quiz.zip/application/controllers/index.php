<?php
class Index extends CI_Controller
{
public function show()
{

	if($this->session->userdata('admin_email'))
	{
		redirect('admin_home/home');
	}
	$this->load->view('admin/login.php');
}


public function form_validation()
{
$this->form_validation->set_rules('email','Email','required|trim|valid_email');
$this->form_validation->set_rules('password','Password','required|trim|min_length[8]');
if($this->form_validation->run()==TRUE)
{
$email=$this->input->post('email');
$password=$this->input->post('password');
$data= array('email'=>$email, 'password'=>$password);
$this->load->model('Admin_model');
$result=$this->Admin_model->login($data);
$row=$result->num_rows();
if($row==1)
{
//set the session variable and redirect to the home page
foreach ($result->result() as $row)  
{
$uname=$row->user_name;
$email=$row->email;
$id=$row->id;
}
$loggedin= array('admin_id'=>$id,'admin_email'=>$email,'admin_uname'=>$uname);
$this->session->set_userdata($loggedin);
redirect('admin_home/home');
}
else
{
$this->session->set_flashdata('login_failed','Incorrect User name or password');
redirect('index/show');
}

}
else
{
$this->session->error="1";
$this->session->mark_as_flash('error');
$this->show();
}

}


public function logout()
{
//$this->load->view('admin/logout.php');//-------place to destory the session variables
$this->session->sess_destroy();
redirect('index/show');


}


}
?>