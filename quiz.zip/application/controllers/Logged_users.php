<?php
	class Logged_users extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('user_model');
		}
		
		public function home()
		{
			$this->load->view('user/header');
			$this->load->view('user/index');
			$this->load->view('user/footer');
		}
		
		public function profile()
		{
			$id=$this->session->userdata('id');
			$data['user_details']=$this->user_model->user_data($id);
			$this->load->view('user/header');
			$this->load->view('user/profile',$data);
			$this->load->view('user/footer');
		}
		
		public function edit_profile()
		{
			$id=$this->session->userdata('id');
			$data['user_details']=$this->user_model->user_data($id);
			$this->load->view('user/header');
			$this->load->view('user/edit_profile',$data);
			$this->load->view('user/footer');
		}
		
		public function update()
		{
			$this->form_validation->set_rules('email','Email','required|valid_email|trim');
			$this->form_validation->set_rules('first_name','First Name','required|trim|min_length[4]|alpha');
			$this->form_validation->set_rules('date','Date of Birth','required');
			if($this->form_validation->run()==TRUE)
				{
					$id=$this->session->userdata('id');
					$first_name=$this->input->post('first_name');
					$last_name=$this->input->post('last_name');
					$dob=$this->input->post('date');
					$data=array('first_name'=>$first_name,'last_name'=>$last_name,'dob'=>$dob);
					$res=$this->user_model->update_user($data,$id);
					$this->session->set_flashdata('updated','Updated Successfully');
					redirect('Logged_users/edit_profile');
				}
			else
				{
				
					$id=$this->session->userdata('id');
					$data['user_details']=$this->user_model->user_data($id);
					$this->load->view('user/header');
					$this->load->view('user/edit_profile',$data);
					$this->load->view('user/footer');
				}
		}
		
		public function change_password()
			{
				$this->load->view('user/header');
				$this->load->view('user/change_password');
				$this->load->view('user/footer');
			}
			
		public function update_password()
			{
				$this->form_validation->set_rules('old_password','Old Password','required|min_length[8]');
				$this->form_validation->set_rules('new_password','New Password','required|min_length[8]');
				$this->form_validation->set_rules('conf_password','Conform Password','required|matches[new_password]');
				if($this->form_validation->run()==TRUE)
				{
					$id=$this->session->userdata('id');
					$old=md5($this->input->post('old_password'));
					$new=md5($this->input->post('new_password'));
					$res=$this->user_model->user_data($id);
					foreach($res as $row)
					{
					$password=$row['password'];
					}
					if($old==$password)
					{
						$new=array('password'=>$new);
						$res1=$this->user_model->update_password($new,$id);
						if($res==1)
						{
						$this->session->set_flashdata('password','Password Changed');
						}
						else
						{
						$this->session->set_flashdata('password','Password Changed');
						}
						
					}
					else
					{
						$this->session->set_flashdata('password','Incorrect Old Password');
					}
					redirect('Logged_users/change_password');
				
				}
				else
				{
					$this->load->view('user/header');
					$this->load->view('user/change_password');
					$this->load->view('user/footer');
				}
			}
		public function quiz()
			{
				// $id=$this->session->userdata('id');
				$this->load->model('test');
				// $this->test->get_test_attended($id);
				$data['test']=$this->test->get_test();
				$this->load->view('user/header');
				$this->load->view('user/quiz_list',$data);
				$this->load->view('user/footer');
			}
		public function test_hall()
			{
				$user_id=$this->session->userdata('id');
				$id=$_REQUEST['id'];
				$this->load->model('test');
				$result=$this->test->user_test($user_id,$id);
				
				if($result==0)
					{
					$res=$this->test->get_num_of_rows($id);
					$allowed_users=$this->test->get_num_of_users($id);
					foreach ($allowed_users as $row)
					{
						$allowed= $row['no_of_users'];
					}
					
					if($res<=$allowed)
						{
						$data['test']=$this->test->get_test_hall($id);
						$this->load->model('test');
						$this->load->view('user/test_hall',$data);
						$this->load->view('user/footer');
						}
					else
						{
							$this->session->set_flashdata('success','Quiz has been Completed..!');
						}
					} 
				else
					{
						$this->session->set_flashdata('done','completed');
						redirect('Logged_users/certificate');
					
					}
				
			}
		public function result()
			{
				$this->load->view('user/header');
				$this->load->view('user/test_result');
				$this->load->view('user/footer');
			}
			
		public function certificate()
			{
				$id=$this->session->userdata('id');
				$this->load->model('test');
				$data['certificate']=$this->test->get_certificate($id);
				$this->load->view('user/header');
				$this->load->view('user/certificate',$data);
				$this->load->view('user/footer');
			}
	}

?>