<?php 
Class Admin_model extends CI_Model
{
	public function __construct()
    {
        parent::__construct();
		$this->load->database();
		
    }
	
	public function login($data)
	{
		$email=$data['email'];
		$password=md5($data['password']);
		$this->db->from('admin');
		$this->db->where('email',$email);
		$this->db->where('password',$password);
		$query = $this->db->get();
		return $query;
	}
	
	public function insert($data)
	{
			$qry=$this->db->insert('admin', $data);
			return $qry;
	}
	
	public function admin_num()
	{
			$this->db->from('admin');
			$query = $this->db->get();
			$rowcount = $query->num_rows();
			return $rowcount;
	}
	
	public function admin_details()
	{
			$this->db->from('admin');
			$query = $this->db->get();
			return $query;
	}
	
	
	public function get_details($id)
	{
		$this->db->from('admin');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query;
	}
	
	public function update($data)
	{
		$id=$data['id'];
		$this->db->set($data); 
		$this->db->where('id',$id);
		$query=$this->db->update("admin", $data);
		return $query;
	}
	
	public function delete($id)
	{
		$del="id=".$id;
		$res=$this->db->delete("admin",$del );
		return $res;
	}
	
	public function change_password($data)
	{
		$id=$data['id'];
		$old_pass=$data['old_pass'];
		$new_pass=$data['new'];
		$pass= array('password'=>$new_pass);
		
		$this->db->from('admin');
		$this->db->where('id',$id);
		$this->db->where('password',$old_pass);
		$query = $this->db->get();
		return $query->num_rows();
		
		/* print_r($query);exit; */
		/* $old_pass1=md5($data['old_pass']);
		$new_pass1=md5($data['new_pas']);
		$update=array('password'=>$new_pass1);
		 */
		
		
		// $this->db->where('id',$id);
		// $this->db->where('password',$old_pass1);
		// $query=$this->db->update("admin", $update);
		
		
		
		
	}
	
	
	public function change_password1($data,$id)
	{
		$this->db->where('id',$id);
		$query=$this->db->update("admin", $data);
		return $query;
	}
	
	public function user_count()
	{
		$this->db->from('user');
		$query = $this->db->get();
		$rowcount = $query->num_rows();
		return $rowcount;
		
	}
	
	public function user_details()
	{
		$this->db->from('user');
		$query = $this->db->get();
		return $query->result_array();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function check_mail($email)
	{
		$this->db->from('admin');
		$this->db->where('email',$email);
		$query = $this->db->get();
		$rowcount = $query->num_rows();
		if($rowcount>0)
		{
			echo 'Email Already Registered';
		}
		else
		{
			echo'';
		}
	}
	
	
}

?>