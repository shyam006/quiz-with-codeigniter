<?php
	class Test extends CI_Model
		{
		function __construct()
			{
				parent::__construct();
				
			}
		public function add_quiz($data)
			{
			
				$this->db->from('test');
				$qry=$this->db->insert('test',$data);
				return $qry;
			}
		
		public function get_test()
			{
				$this->db->from('test');
				$qry=$this->db->get();
				return $qry->result_array();
			}
			
			public function get_test_hall($id)
			{
				$this->db->from('test');
				$this->db->where('id',$id);
				$qry=$this->db->get();
				return $qry->result_array();
			}
		public function get_test_num()
			{
				$this->db->from('test');
				$qry=$this->db->get();
				$row=$qry->num_rows();
				return $row;
			}
		public function delete($id)
			{
				$this->db->from('test');
				$this->db->where('id',$id);
				$qry=$this->db->delete('test');
				return $qry;
			}
		public function get_test_id($id)
			{
				$this->db->from('test');
				$this->db->where('id',$id);
				$qry=$this->db->get();
				return $qry->result_array();
			}
		public function edit_test($data,$id)
			{
				$this->db->from('test');
				$this->db->where('id',$id);
				$qry=$this->db->update('test',$data);
				return $qry;
			}
		public function result($data)
			{
				$this->db->from('result');
				$qry=$this->db->insert('result',$data);
				return $this->db->insert_id();
			}
		public function user_test($user_id,$id)
			{
				$this->db->from('result');
				$this->db->where('user_id',$user_id);
				$this->db->where('test_id',$id);
				$qry=$this->db->get();
				return $qry->num_rows();
			}
		public function get_num_of_rows($id)
			{
				$this->db->from('result');
				$this->db->where('test_id',$id);
				$qry=$this->db->get();
				return $qry->num_rows();
			}
		public function get_num_of_users($id)
			{
				$this->db->from('test');
				$this->db->where('id',$id);
				$qry=$this->db->get();
				return $qry->result_array() ;
			}
		public function update_certificate($c_name ,$res_id)
			{
				$array= array('certificate'=>$c_name);
				$this->db->from('result');
				$this->db->where('id',$res_id);
				$qry=$this->db->update('result',$array);
				return $qry;
			}
		public function get_certificate($id)
			{
				$this->db->select('test.min_percentage,result.percentge,result.test_id,test.title,result.certificate');
				$this->db->from('result');
				$this->db->where('user_id',$id);
				$this->db->join('test','test.id=result.test_id');
				$qry=$this->db->get();
				
				//$qry = $this->db->query('SELECT result.test_id, test.title,test.min_percentage,result.percentge,result.certificate from result join test on result.test_id=test.id');
				
				return $qry->result_array();
			}
		}
?>