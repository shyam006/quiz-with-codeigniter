<?php
class user_model extends CI_Model
{
	public function add_user($data)
		{
			$qry=$this->db->insert('user',$data);
			return $qry;
		}
		
	public function check_mail($email)
		{	
			
			$this->db->from('user');
			$this->db->where('email',$email);
			$query = $this->db->get();
			$rowcount = $query->num_rows();
			if($rowcount>0)
				{
					echo 'Email Already Registered';
				}
			else
				{
					echo'';
				}
		}
	public function check_login($data)
		{
			$this->db->from('user');
			$this->db->where('email',$data['email']);
			$this->db->where('password',md5($data['password']));
			$qry=$this->db->get();
			return $qry->result_array();
			
		}
		
	public function user_data($id)
		{
			$this->db->from('user');
			$this->db->where('id',$id);
			$qry=$this->db->get();
			return $qry->result_array();
		}
	public function update_user($data,$id)
		{
			$this->db->from('user');
			$this->db->where('id', $id);
			$qry=$this->db->update('user',$data);
			return $qry;
		}
	public function update_password($new,$id)
		{
			$this->db->from('user');
			$this->db->where('id',$id);
			$qry=$this->db->update('user',$new);
			return $qry;
		}

}
?>