
                    <div class="span9">
                        <?php echo form_open('admin_home/remove_admin');?>
                        
						<div class="control-group">
						<label class="control-label" for="basicinput">Admin to delete.</label>
						<div class="controls">
						<select name="admin" tabindex="1" data-placeholder="Select Admin " class="span8">
						<option value="">Select Admin ...</option>
						<option value="Category 1">List of Admins</option>
						</select>
						</div>
						<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('admin').'</span>';
								}
								?>
						</div>
							                           
                            <div class="control-group">
							<div class="controls"style="text-align:center;">
							<button type="submit" class="btn">Submit</button>
							</div>
							</div>
                            
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
