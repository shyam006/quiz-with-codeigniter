 <?php
	foreach ($details->result() as $row)  
	{
		$id=$row->id;
		$fname=$row->first_name;
		$lname=$row->last_name;
		$uname=$row->user_name;
		$email=$row->email;
		
	}
 
 ?>
 
 <div class="span9">
                        <div>
						<div class="control-group">
							<div class="controls"style="text-align:right;">
							<a class="btn btn-info" href="<?php echo base_url('index.php/admin_home/edit_admin').'?id='.$id?>">Edit</a>
							</div>
							</div>
						</div>
						<input type="hidden" name="id" value="<?php echo $id; ?>">
                          <div class="control-group">
							<label class="control-label" for="basicinput">Email</label>
							<div class="controls">
								<input readonly value="<?php echo $email; ?>"  type="email" name="email" id="basicinput" class="span8">
							
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput">First Name</label>
							<div class="controls">
								<input readonly value="<?php echo $fname;?>" type="text" name="fname" id="basicinput" class="span8">
							
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput">Last Name</label>
							<div class="controls">
								<input readonly value="<?php echo $lname;?>" type="text" name="lname" id="basicinput" class="span8">
						
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput">User Name</label>
							<div class="controls">
								<input readonly value="<?php echo $uname;?>" type="text" name="uname" id="basicinput" class="span8">
							
								</div>
							</div>
							                           
                            
                            
							
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
