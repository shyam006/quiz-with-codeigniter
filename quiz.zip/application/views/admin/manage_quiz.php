
                    <div class="span9">
					<div class="text-right">
					<a href="<?php echo base_url('admin_home/add_quiz');?>"><button class="btn btn-primary">Add Quiz</button></a>
					</div><br>
                       <?php
						if($this->session->flashdata('success'))
					{
					
					echo'
					<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>'.$this->session->flashdata('success').'</strong>
									</div>
					';
					}
					   echo form_open('admin_home/remove_users');?>
					   <div class="module">
                                <div class="module-head">
                                    <h3>
                                        Quiz List</h3>
                                </div>
                                <div class="module-body table">
                                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display"
                                        width="100%">
                                        <thead>
                                            <tr>
											 
                                             <th>
                                                  Title
                                             </th>
                                             <th>
                                                  Duration (Mins)
                                             </th>
                                             <th>
                                                 Created Date
                                             </th>
											 <th>
                                                 Options
                                             </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                           
                                           <?php
												foreach($test as $row)
												{
													$id=$row['id'];
													$title=$row['title'];
													$date=$row['date'];
													$time=$row['duration'];
													$delete=base_url('index.php/quiz/delete_quiz').'?id='.$id;
													$edit=base_url('index.php/admin_home/edit_quiz').'?id='.$id;
													echo'
													<tr class="odd gradeA">
												<td>
                                                    '.$title.'
                                                </td>
                                                <td>
                                                    '.$time.'
                                                </td>
                                                <td>
                                                    '.$date.'
                                                </td>
                                              
												<td>
                                                    <a href="'.$edit.'"><button type="button" class="btn btn-info">Edit</button></a> <a href="'.$delete.'" onclick= "return doconfirm()"><button type="button" class="btn btn-danger">Delete</button></a>
                                                </td>
                                            </tr>
													
													';
												}
											?>
                                            

                                        <tfoot>
                                         <tr>
											 
                                             <th>
                                                  Title
                                             </th>
                                             <th>
                                                  Duration (Mins)
                                             </th>
                                             <th>
                                                 Created Date
                                             </th>
											 <th>
                                                 Options
                                             </th>
                                        </tr>
                                        </tfoot>
                                    </table>
								</div>
								</div>
								 
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
		<script>
		 
   function doconfirm()
{

var delete_content=confirm("Are you sure want to delete this record?");
if(delete_content!=true)
{
return false;
}
}
</script>