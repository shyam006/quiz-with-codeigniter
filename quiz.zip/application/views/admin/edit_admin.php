<?php
if(isset($_GET['id']))
{
foreach ($details->result() as $row)  
	{
		$id=$row->id;
		$fname=$row->first_name;
		$lname=$row->last_name;
		$uname=$row->user_name;
		$email=$row->email;
		
	}
}
else
{
		$id=set_value('id');
		$fname=set_value('fname');
		$lname=set_value('lname');
		$uname=set_value('uname');
		$email=set_value('email');
}
?>
                    <div class="span9">
                        <?php echo form_open('admin_home/update_admin');?>
						<input type="hidden" name="id" value="<?php echo $id; ?>">
                          <div class="control-group">
							<label class="control-label" for="basicinput">Email</label>
							<div class="controls">
								<input readonly value="<?php echo $email; ?>"  type="email" name="email" id="basicinput" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('email').'</span>';
								}
								?>
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput">First Name</label>
							<div class="controls">
								<input value="<?php echo $fname;?>" type="text" name="fname" id="basicinput" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('fname').'</span>';
								}
								?>
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput">Last Name</label>
							<div class="controls">
								<input value="<?php echo $lname;?>" type="text" name="lname" id="basicinput" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('lname').'</span>';
								}
								?>
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput">User Name</label>
							<div class="controls">
								<input value="<?php echo $uname;?>" type="text" name="uname" id="basicinput" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('uname').'</span>';
								}
								?>
								</div>
							</div>
							                           
                            <div class="control-group">
							<div class="controls"style="text-align:center;">
							<button type="submit" class="btn">Submit</button>
							</div>
							</div>
                            
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
