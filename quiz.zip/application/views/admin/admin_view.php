
                    <div class="span9">
					<div class="text-right">
					<a href="<?php echo base_url('admin_home/create_admin');?>"><button class="btn btn-primary">Add Admin</button></a>
					</div><br>
					<?php
					if($this->session->flashdata('updated'))
					{
					
					echo'
					<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Updated Successfully</strong>
									</div>
					';
					}
					if($this->session->flashdata('deleted'))
					{
					
					echo'
					<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Deleted Successfully</strong>
									</div>
					';
					}
					?>
					<?php 
					if($this->session->flashdata('success'))
					{
					$success=$this->session->flashdata('success');
					if($success=="Registred Successfully")
					{
					echo'
					<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>'.$success.'</strong>
									</div>
					';
					}
					else
					{
					echo '<div class="alert alert-error">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>'.$success.'</strong>
									</div>';
					}
					
					
					}
					?>
					<br>
                       <?php echo form_open('admin_home/remove_users');?>
					   <div class="module">
                                <div class="module-head">
                                    <h3>
                                        Quiz List</h3>
                                </div>
                                <div class="module-body table">
                                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th>
                                                   First Name
                                                </th>
                                                <th>
                                                    Last Name
                                                </th>
                                                <th>
                                                    USer Name
                                                </th>
                                                <th>
                                                    Email
                                                </th>
												<th>
                                                    Options
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                           <?php
												foreach ($admin->result() as $row)  
													{
													$id=$row->id;
													$edit=base_url('index.php/admin_home/edit_admin').'?id='.$id;
													$delete=base_url('index.php/admin_home/delete_admin').'?id='.$id;
													echo'<tr><td>'.$row->first_name.'</td>
													<td>'.$row->last_name.'</td>
													<td>'.$row->user_name.'</td>
													<td>'.$row->email.'</td>
													<td><a class="btn btn-mini btn-info" href="'.$edit.'">Edit</a> <a class="btn btn-mini btn-danger" href="'.$delete.'" onclick= "return doconfirm()">Delete</a></td>
													</tr>';
													}
										   ?>
                                           

                                        <tfoot>
                                           <tr>
                                                <th>
                                                   First Name
                                                </th>
                                                <th>
                                                    Last Name
                                                </th>
                                                <th>
                                                    USer Name
                                                </th>
                                                <th>
                                                    Email
                                                </th>
												<th>
                                                    Options
                                                </th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
								
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
		
		<script>
		 
   function doconfirm()
{

var delete_content=confirm("Are you sure want to delete this record?");
if(delete_content!=true)
{
return false;
}
}

   </script>
       
