
                    <div class="span9">
					<?php
					if($this->session->flashdata('change_pass'))
					{
					echo '<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>'.$this->session->flashdata('change_pass').'</strong>
									</div>';
					}
					
					
					?>
					
							<?php echo form_open('admin_home/set_password');?>
                          <div class="control-group">
							<label class="control-label" for="basicinput">old Password</label>
							<div class="controls">
								<input type="password" name="old_pass" id="basicinput" placeholder="Enter your old Password" class="span8">
								</div>
								<?php
								
								
								echo form_error('old_pass','<p style="color:red">');
								
								?>
							</div>
							
							 <div class="control-group">
							<label class="control-label" for="basicinput">New Password</label>
							<div class="controls">
								<input type="password" name="new_pass" id="basicinput" placeholder="Enter your New Password" class="span8">
								</div>
								<?php
							
								echo '<span style="color:red">'.form_error('new_pass').'</span>';
							
								?>
							</div>
							
							 <div class="control-group">
							<label class="control-label" for="basicinput">Confirm Password</label>
							<div class="controls">
								<input type="password" name="conf_pass" id="basicinput" placeholder="Enter your New Password" class="span8">
								</div>
								<?php
							
								echo '<span style="color:red">'.form_error('conf_pass').'</span>';
								
								?>
							</div>
							
							  <div class="control-group">
							<div class="controls"style="text-align:center;">
							<button type="submit" class="btn">Submit</button>
							</div>
							</div>
							
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
