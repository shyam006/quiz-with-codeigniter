<!DOCTYPE html>
<html lang="en">
<head>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Quiz</title>
        <link type="text/css" href="<?php echo base_url();?>assets/admin/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="<?php echo base_url();?>assets/admin/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="<?php echo base_url();?>assets/admin/css/theme.css" rel="stylesheet">
        <link type="text/css" href="<?php echo base_url();?>assets/admin/images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
            rel='stylesheet'>
    </head>
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a><a class="brand" href="admin_home/home">Quiz </a>
                    <div class="nav-collapse collapse navbar-inverse-collapse">
                        
                        <ul class="nav pull-right">
                            <li class="nav-user dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <!-- <img src="<?php echo base_url();?>assets/admin/images/user.png" class="nav-avatar" /> -->
								<?php
								echo $this->session->userdata('admin_uname');
								?>
                                <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="profile">Your Profile</a></li>
                                    <li><a href="change_password">Change Password</a></li>
                                    <li class="divider"></li>
                                    <li><a href="<?php echo base_url('index/logout');?>">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>
        <!-- /navbar -->
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="span3">
                        <div class="sidebar">
                            <ul class="widget widget-menu unstyled">
                                <li class="active"><a href="<?php echo base_url('admin_home/home')?>"><i class="menu-icon icon-dashboard"></i>Dashboard
                                </a></li>
                                </ul>
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                <li><a href="<?php echo base_url('admin_home/admin_view')?>"><i class="menu-icon icon-cog">
                                </i></i>Administrator</a></li>
                              </ul>
                            
							<ul class="widget widget-menu unstyled">
							<li class="active"><a href="<?php echo base_url('admin_home/view_users')?>"><i class="menu-icon icon-dashboard"></i>Users
                                </a></li>
                            </ul>
							
							<ul class="widget widget-menu unstyled">
                                <li><a href="<?php echo base_url('admin_home/manage_quiz')?>"><i class="menu-icon icon-cog">
                                </i></i>Quiz</a></li>
                              </ul>
							
                       
                            <!--/.widget-nav-->
                            
                        </div>
                        <!--/.sidebar-->
                    </div>