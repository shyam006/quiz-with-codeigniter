<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
function options(val)
{
	var id=val ;
	if(id=="single")
		{
			document.getElementById("divsingle").style.display = "block";
			document.getElementById("divmultiple").style.display = "none";
		//$('#option').append(''); //add input box
		}
	else
		{
				document.getElementById("divsingle").style.display = "none";
			document.getElementById("divmultiple").style.display = "block";
		}
}
</script>
                    <div class="span9">
                       
					   <div class="control-group">
							<label class="control-label" name="title" for="basicinput">Quiz Title</label>
							<div class="controls">
								<input type="text" id="basicinput" placeholder="Enter Quiz Title..." class="span8">
							</div>
						</div>
					   
					<div class="control-group">
					   <div class="control-group">
							<label class="control-label" for="basicinput">Question</label>
							<div class="controls">
								<textarea name="question" class="span8" rows="2" placeholder="Enter Question..."></textarea>
							</div>
						</div>
						<div class="control-group">
											<label class="control-label">Answer Type</label>
											<div class="controls">
												<label class="radio inline">
													<input type="radio" name="optionsRadios" onclick="options(this.id)" id="single" value="option1" checked="" >
													 Single Option
												</label> 
												<label class="radio inline">
													<input type="radio" name="optionsRadios" onclick="options(this.id)" id="multiple" value="option2">
													Multiple Option
												</label> 
												
											</div>
										</div>
						
						<div class="control-group">
							<label class="control-label">Answers</label>
							
							
							<div class="controls option" id="divsingle" >
								<div class="input-prepend">
									<span class="add-on"><input type="radio" name="optionsRadios" id="optionsRadios1" value=""></span>
									<input class="span8" type="text" placeholder="Option">
								</div>
								<div class="input-prepend">
									<span class="add-on"><input type="radio" name="optionsRadios" id="optionsRadios2" value=""></span>
									<input class="span8" type="text" placeholder="Option">
								</div>
								
							</div>
							
							<div class="controls option" id="divmultiple" style="display:none">
								<div class="input-prepend">
									<span class="add-on"><input type="checkbox" name="checkbox" id="checkbox1" value=""></span>
									<input class="span8" type="text" placeholder="Option">
								</div>
								<div class="input-prepend">
									<span class="add-on"><input type="checkbox" name="checkbox" id="checkbox2" value=""></span>
									<input class="span8" type="text" placeholder="Option">
								</div>
								
							</div>
							<div class="controls">
									<button type="button" id="multiplebutton" onclick="addoption(this.id);" class="btn">Add Option</button>
								</div>
							
						</div>
                    </div>
					
                    </div>
                        <!--/.content-->
                </div>
                    <!--/.span9-->
            </div>
        </div>
            <!--/.container-->
    </div>
        <!--/.wrapper-->
       
