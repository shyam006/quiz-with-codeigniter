<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script> 

function load()
{

var email=document.getElementById('email');
var value = document.getElementById('email').value;
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
if(filter.test(value))
{

	$.ajax({type:"GET",url:'check_mail',data:{ email:value},
	
	success:function(response)
		{
		
			$("#email_status").html(response); 
		}
		
		});


}

else
{
document.getElementById('email_status').innerHTML="Enter a valid Email Id";
}

}
</script>

				<div class="span9">
					
					
                        <?php echo form_open('admin_home/add_admin');?>
                          <div class="control-group">
							<label class="control-label" for="basicinput1">Email</label>
							<div class="controls">
								<input value="<?php echo set_value('email');?>" id="email" type="email" name="email" id="basicinput1" onkeyup="load();" placeholder="Enter your Email" onkeyup="check_email();" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('email').'</span>';
								}
								?>
								<span class="help-inline" style="color:red" id="email_status"></span>
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput2">First Name</label>
							<div class="controls">
								<input value="<?php echo set_value('fname');?>" type="text" name="fname" id="basicinput2" placeholder="Enter your First Name" class="span8">
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput3">Last Name</label>
							<div class="controls">
								<input value="<?php echo set_value('lname');?>" type="text" name="lname" id="basicinput3" placeholder="Enter your Last Name" class="span8">
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput4">User Name</label>
							<div class="controls">
								<input value="<?php echo set_value('name');?>" type="text" name="name" id="basicinput4" placeholder="Enter your Name" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('name').'</span>';
								}
								?>
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput5">Password</label>
							<div class="controls">
								<input  type="password" name="password" id="basicinput5" placeholder="Enter your Password" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('password').'</span>';
								}
								?>
								</div>
							</div>
							
							<div class="control-group">
							<label class="control-label" for="basicinput">Confirm Password</label>
							<div class="controls">
								<input type="password" name="conf_password" id="basicinput" placeholder="Enter your Password" class="span8">
								<?php
								if(isset($_SESSION['error']))
								{
								echo '<span class="help-inline" style="color:red">'.form_error('conf_password').'</span>';
								}
								?>
								</div>
							</div>
                           
                            <div class="control-group">
							<div class="controls"style="text-align:center;">
							<button type="submit" class="btn">Submit</button>
							</div>
							</div>
                            
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
