<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<?php
foreach ($edit as $row)
	{
		$id=$row['id'];
		$title=$row['title'];
		$users=$row['no_of_users'];
		$ques=$row['questions'];
		$type=$row['type'];
		$options=$row['options'];
		$answer=$row['answers'];
		$min_percentage=$row['min_percentage'];
		//decoding the string to array format//
		$ques=json_decode($ques);
		$type=json_decode($type);
		$options=json_decode($options);
		$answer=json_decode($answer);
	}
?>


                    <div class="span9">
                       <?php echo form_open('quiz/edit_quiz');?>

					  
					   
					   <div class="col-smd-8">
					   <div class="control-group">
							<label class="control-label" name="title" for="basicinput">Quiz Title</label>
							<input type="hidden" value="<?php echo $_REQUEST['id']; ?>" name="test_id">
							<div class="controls">
								<input type="text" name="quiz_title" id="basicinput" value="<?php echo $title; ?>" placeholder="Enter Quiz Title..." class="span8" required>
							</div>
						</div>
					   </div>
					   
					   <div class="col-sm-4">
						<div class="control-group">
							<label class="control-label" name="title" for="basicinput">Max. No. Of Students to Attend Test </label>
							<div class="controls">
								<input type="number" min="1" value="<?php echo $users; ?>" name="users" id="basicinput" placeholder="Enter No. of Students..." class="span3" required>
							</div>
							<label class="control-label" name="title" for="basicinput12">Min. Percentage to get Certificate </label>
							<div class="controls">
								<input type="number" min="40" value="<?php echo $min_percentage; ?>" name="min_percentage" id="basicinput12" placeholder="Enter Min. Percentage.." class="span1" required>
							</div>
						</div>
					   </div>
					   
					 

					<div id="add_quiz">
							
							
							<?php

for($i=0;$i<count($ques);$i++)
	{
		$qno=$i+1;
		$ques_type=$type[$i];
		switch($ques_type)
		{
			case "single":
			{
				echo'
				<div id="question_'.$qno.'">
					<input type="hidden" value="single" name="option_type_'.$qno.'">
					<h2>Question-'.$qno.'</h2>
					<div class="controls">
						<textarea name="ques[]" class="question span8" id="question_'.$qno.' "rows="2" placeholder="Enter Question..." required>'.$ques[$i].'</textarea>
					</div>
					<div class="controls option" id="divsingle_'.$qno.'">
						<div  id="single_option_'.$qno.'">
							<label class="control-label">Answers</label>
				';
				$opt_no=0;
				foreach ($options[$i] as $row)
				{
				$opt_no++;
				foreach ($answer[$i] as $answer_saved)
					{
						if($row==$answer_saved)
						{
							echo'
							<div class="input-prepend">
								<span class="add-on"><input class="ques_'.$qno.'_radio" type="radio" checked  name="ques_'.$qno.'_ans[]" value="'.$row.'" id="ans_'.$qno.'_'.$opt_no.'" required ></span>
								<input class="span8 ques_'.$qno.'_radio" onkeyup="optval(this)" data-ans="ans_'.$qno.'_'.$opt_no.'" name="ques_'.$qno.'_opt[]" value="'.$row.'" id="opt_'.$qno.'_'.$opt_no.'" type="text" placeholder="Option" required >
							</div>
							';
						}
						else
						{
							echo'
							<div class="input-prepend">
								<span class="add-on"><input class="ques_'.$qno.'_radio" type="radio" name="ques_'.$qno.'_ans[]" value="'.$row.'" id="ans_'.$qno.'_'.$opt_no.'" required ></span>
								<input class="span8 ques_'.$qno.'_radio" onkeyup="optval(this)" data-ans="ans_'.$qno.'_'.$opt_no.'" name="ques_'.$qno.'_opt[]" value="'.$row.'" id="opt_'.$qno.'_'.$opt_no.'" type="text" placeholder="Option" required >
							</div>
							';
						}
					}
					
				}
				echo'
						</div>
						<div class="controls">
							<span id="addoption_'.$qno.'" onclick="addoption(this)" data-ques="'.$qno.'" data-type="single"  id="add" class="btn btn-primary">Add Option</span>
							<button type="button" id="deleteoption_'.$qno.'" onclick="deloption(this)" data-ques="'.$qno.'" data-type="single"  id="del" class="btn btn-danger">Remove</button>
						</div>
					</div>
				</div><br>
				';
				
				break;
			}
				
			case "multiple":
			{
				echo'
					<div id="question_'.$qno.'">
						<input type="hidden" value="multiple" name="option_type_'.$qno.'">
						<h2>Question-'.$qno.'</h2>
						<div class="controls">
							<textarea name="ques[]" class="question span8" id="question_'.$qno.' "rows="2" placeholder="Enter Question..." required>'.$ques[$i].'</textarea>
						</div>
						<div class="controls option" id="divmultiple_'.$qno.'" >
							<div  id="multiple_option_'.$qno.'">
								<label class="control-label">Answers</label>
				';
				$opt_no=0;
				foreach ($options[$i] as $row1)
				{
					$matched=0;
					$opt_no++;
					foreach ($answer[$i] as $answer_saved1)
					{
						if($row1==$answer_saved1)
						{
							$matched+=1;
						}
						else
						{
							$matched+=0;
						}
						
						
					}
					if($matched>0)
					{
					echo'<div class="input-prepend">
								<span class="add-on"><input class="ques_'.$qno.'_radio" type="checkbox" name="ques_'.$qno.'_ans[]" checked value="'.$row1.'" id="ans_'.$qno.'_'.$opt_no.'"  ></span>
								<input class="span8 ques_'.$qno.'_radio" onkeyup="optval(this)" data-ans="ans_'.$qno.'_'.$opt_no.'" name="ques_'.$qno.'_opt[]" value="'.$row1.'" id="opt_'.$qno.'_'.$opt_no.'" type="text" placeholder="Option" required >
							</div>';
					}
					else
					{
					echo'<div class="input-prepend">
								<span class="add-on"><input class="ques_'.$qno.'_radio" type="checkbox" name="ques_'.$qno.'_ans[]" value="'.$row1.'" id="ans_'.$qno.'_'.$opt_no.'"  ></span>
								<input class="span8 ques_'.$qno.'_radio" onkeyup="optval(this)" data-ans="ans_'.$qno.'_'.$opt_no.'" name="ques_'.$qno.'_opt[]" value="'.$row1.'" id="opt_'.$qno.'_'.$opt_no.'" type="text" placeholder="Option" required >
							</div>';
					}
					
				}
				echo'
								</div>
							<div class="controls">
								<button type="button" id="addoption_'.$qno.'" onclick="addoption(this)" data-ques="'.$qno.'" data-type="multiple"  id="add" class="btn btn-primary">Add Option</button> 
								<button type="button" id="deleteoption_'.$qno.'" onclick="deloption(this)" data-ques="'.$qno.'" data-type="multiple"  id="del" class="btn btn-danger">Remove</button>
							</div>
						</div>
					</div>
				
				';
				break;
			}
			
			case "boolean":
			{
				echo'
				<div id="question_'.$qno.'">
					<input type="hidden" value="single" name="option_type_'.$qno.'">
					<h2>Question-'.$qno.'</h2>
					<div class="controls">
						<textarea name="ques[]" class="question span8" id="question_'.$qno.' "rows="2" placeholder="Enter Question..." required>'.$ques[$i].'</textarea>
					</div>
					<div class="controls option" id="divsingle_'.$qno.'">
						<div  id="single_option_'.$qno.'">
							<label class="control-label">Answers</label>
				';
				$opt_no=0;
				foreach ($options[$i] as $row)
				{
				$opt_no++;
					foreach ($answer[$i] as $answer_saved)
					{
						if($row==$answer_saved)
						{
							echo'
							<div class="input-prepend">
								<span class="add-on"><input class="ques_'.$qno.'_radio" type="radio" checked  name="ques_'.$qno.'_ans[]" value="'.$row.'" id="ans_'.$qno.'_'.$opt_no.'" required ></span>
								<input readonly class="span8 ques_'.$qno.'_radio" onkeyup="optval(this)" data-ans="ans_'.$qno.'_'.$opt_no.'" name="ques_'.$qno.'_opt[]" value="'.$row.'" id="opt_'.$qno.'_'.$opt_no.'" type="text" placeholder="Option" required >
							</div>
							';
						}
						else
						{
							echo'
							<div class="input-prepend">
								<span class="add-on"><input class="ques_'.$qno.'_radio" type="radio" name="ques_'.$qno.'_ans[]" value="'.$row.'" id="ans_'.$qno.'_'.$opt_no.'" required ></span>
								<input readonly class="span8 ques_'.$qno.'_radio" onkeyup="optval(this)" data-ans="ans_'.$qno.'_'.$opt_no.'" name="ques_'.$qno.'_opt[]" value="'.$row.'" id="opt_'.$qno.'_'.$opt_no.'" type="text" placeholder="Option" required >
							</div>
							';
						}
					}
				}
				echo'
						</div>
						<div class="controls">
							<span id="addoption_'.$qno.'" onclick="addoption(this)" data-ques="'.$qno.'" data-type="single"  id="add" class="btn btn-primary">Add Option</span>
							<button type="button" id="deleteoption_'.$qno.'" onclick="deloption(this)" data-ques="'.$qno.'" data-type="single"  id="del" class="btn btn-danger">Remove</button>
						</div>
					</div>
				</div><br>
				';
				
				break;
			}
			
			
		}
		
		
		
		
	}
		
?>
							
							
							
					</div>
					<div class="control-group">
								<label class="control-label">Answer Type</label>
								<div class="controls">
									<label class="radio inline btn"><input style="display:none" type="radio"  data-type="single" data-ques="1"  id="single" value="radio">
									Single Answer</label> 
									<label class="radio inline btn"><input style="display:none" type="radio" data-type="check" data-ques="1"   id="multiple" value="Check" >
									Multiple Answer</label> 
									<label class="radio inline btn"><input style="display:none" type="radio" data-type="t/f" data-ques="1"   id="t_f" value="radio" >
									True/False</label> 
								</div>
								</div>
					
					<br><br>
					
					
					
					
					
					
					
					<div  style="text-align: right;">
						<span class="btn btn-danger" id="del_que">Delete Question</span>
					</div>
					<br><br><br>
					<div class="control-group">
						<button type="submit" class="btn btn-success">Update</button>
					</div>
                     <?php echo form_close();?>
					</div>
                        <!--/.content-->
                </div>
                    <!--/.span9-->
            </div>
        </div>
            <!--/.container-->
    </div>
        <!--/.wrapper-->
      <script>

   // var e = $('textarea').length;
	  // if(e>0)
		  // {
			// $('#del_que').show();
		  // }
	  // else
		  // {
			// $('#del_que').hide();
		  // }

	  

$('#single').click(function(){
	var c = $('textarea').length;
	var b = c+1;
	$('#add_quiz').append('<div id="question_'+b+'"><input type="hidden" value="single" name="option_type_'+b+'"><h2>Question-'+b+'</h2><div class="controls"><textarea name="ques[]" class="question span8" id="question_'+b+' "rows="2" placeholder="Enter Question..." required></textarea></div><div class="controls option" id="divsingle_'+b+'"><div  id="single_option_'+b+'"><label class="control-label">Answers</label><div class="input-prepend"><span class="add-on"><input class="ques_'+b+'_radio" type="radio" checked  name="ques_'+b+'_ans[]" value="option '+b+'" id="ans_'+b+'_1" required ></span><input class="span8 ques_'+b+'_radio" onkeyup="optval(this)" data-ans="ans_'+b+'_1" name="ques_'+b+'_opt[]" id="opt_'+b+'_1" type="text" placeholder="Option" required ></div><div class="input-prepend"><span class="add-on"><input type="radio" name="ques_'+b+'_ans[]"  value="option 2" id="ans_'+b+'_2"  ></span><input class="span8" name="ques_'+b+'_opt[]" id="opt_'+b+'_2" data-ans="ans_'+b+'_2" onkeyup="optval(this)" type="text" placeholder="Option" required ></div><div class="input-prepend"><span class="add-on"><input class="ques_'+b+'_radio" type="radio" name="ques_'+b+'_ans[]" value="option 3" id="ans_'+b+'_3"  ></span><input class="span8 ques_'+b+'_radio" onkeyup="optval(this)" data-ans="ans_'+b+'_3" id="opt_'+b+'_3" name="ques_'+b+'_opt[]" type="text" placeholder="Option" required ></div></div><div class="controls"><span id="addoption_'+b+'" onclick="addoption(this)" data-ques="'+b+'" data-type="single"  id="add" class="btn btn-primary">Add Option</span> <button type="button" id="deleteoption_'+b+'" onclick="deloption(this)" data-ques="'+b+'" data-type="single"  id="del" class="btn btn-danger">Remove</button></div></div></div>');
});

$('#multiple').click(function(){
	var c = $('textarea').length;
	var b = c+1;
	$('#add_quiz').append('<div id="question_'+b+'"><input type="hidden" value="multiple" name="option_type_'+b+'"><h2>Question-'+b+'</h2><div class="controls"><textarea name="ques[]" class="question span8" id="question_'+b+' "rows="2" placeholder="Enter Question..." required></textarea></div><div class="controls option" id="divmultiple_'+b+'" ><div  id="multiple_option_'+b+'"><label class="control-label">Answers</label><div class="input-prepend"><span class="add-on"><input type="checkbox" name="ques_'+b+'_ans[]" id="ans_'+b+'_1" checked ></span><input class="span8" onkeyup="optval(this)" data-ans="ans_'+b+'_1" id="opt_'+b+'_1" name="ques_'+b+'_opt[]" type="text" placeholder="Option" required></div><div class="input-prepend"><span class="add-on"><input type="checkbox" name="ques_'+b+'_ans[]" id="ans_'+b+'_2" ></span><input class="span8" onkeyup="optval(this)" data-ans="ans_'+b+'_2" id="opt_'+b+'_2" name="ques_'+b+'_opt[]" type="text" placeholder="Option" required></div><div class="input-prepend"><span class="add-on"><input type="checkbox" name="ques_'+b+'_ans[]" id="ans_'+b+'_3" ></span><input class="span8" onkeyup="optval(this)" data-ans="ans_'+b+'_3" id="opt_'+b+'_3" name="ques_'+b+'_opt[]" type="text" placeholder="Option" required></div></div><div class="controls"><button type="button" id="addoption_'+b+'" onclick="addoption(this)" data-ques="'+b+'" data-type="multiple"  id="add" class="btn btn-primary">Add Option</button> <button type="button" id="deleteoption_'+b+'" onclick="deloption(this)" data-ques="'+b+'" data-type="multiple"  id="del" class="btn btn-danger">Remove</button></div></div></div></div>');
});

$('#t_f').click(function(){
	var c = $('textarea').length;
	var b = c+1;
	$('#add_quiz').append('<div id="question_'+b+'"><input type="hidden" value="boolean" name="option_type_'+b+'"><h2>Question-'+b+'</h2><div class="controls"><textarea name="ques[]" class="question span8" id="question_'+b+' "rows="2" placeholder="Enter Question..." required></textarea></div><div class="controls option" id="divtf_'+b+'"><div  id="single_tf_'+b+'"><label class="control-label">Answers</label><div class="input-prepend"><span class="add-on"><input class="ques_'+b+'_radio" type="radio"  name="ques_'+b+'_ans[]" value="True" id="optionstf'+b+'" checked ></span><input readonly class="span8 ques_'+b+'_radio" onkeyup="optval(this)" value="True" name="ques_'+b+'_opt[]" type="text" placeholder="Option" required ></div><div class="input-prepend"><span class="add-on"><input type="radio" name="ques_'+b+'_ans[]" value="False" id="optionstf2" ></span><input readonly class="span8 ques_'+b+'_radio" onkeyup="optval(this)" value="False" name="ques_'+b+'_opt[]" type="text" placeholder="Option" required></div></div></div></div>');
});

$('#del_que').click(function(){
$('#add_quiz').children().last().remove();
});

function optval(div)
{
	var value=div.value;
	var id1=div.getAttribute("data-ans");
	var id='#'+id1;
	$(id).prop('value',value);
	
	
	
}

function deloption(delopt)
{
	var qNo=delopt.getAttribute("data-ques");
	var optionType=delopt.getAttribute("data-type");
	if(optionType=='single')
	{
		var destination='#single_option_'+qNo;
		$(destination).children().last().remove();
	}
	else
	{
		var destination='#multiple_option_'+qNo;
		$(destination).children().last().remove();
	}
}

function addoption(addoption)
{
	var qNo=addoption.getAttribute("data-ques");
	var optionType=addoption.getAttribute("data-type");
	var destination='#single_option_'+qNo;
	var destination1='#multiple_option_'+qNo;
	if(optionType=='single')
	{
		var len=$(destination).find($("input") );
		var id=len.length/2+1;
		$(destination).append('<div class="input-prepend"><span class="add-on"><input class="ques_'+qNo+'_radio" type="radio" name="ques_'+qNo+'_ans[]" value="option 3" id="ans_'+qNo+'_'+id+'"></span><input class="span8 ques_'+qNo+'_radio" data-ans="ans_'+qNo+'_'+id+'" id="opt_'+qNo+'_'+id+'" onkeyup="optval(this)" name="ques_'+qNo+'_opt[]" type="text" placeholder="Option" required=""></div>');
	}
	else
	{
		var len=$(destination1).find($("input") );
		var id=len.length/2+1;
		$(destination1).append('<div class="input-prepend"><span class="add-on"><input type="checkbox" name="ques_'+qNo+'_ans[]" id="ans_'+qNo+'_'+id+'"></span><input class="span8" onkeyup="optval(this)" data-ans="ans_'+qNo+'_'+id+'" id="opt_'+qNo+'_'+id+'" name="ques_'+qNo+'_opt[]" type="text" placeholder="Option"></div>');
		
	}
	
}







</script> 
