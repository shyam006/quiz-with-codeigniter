
                    <div class="span9">
                       <?php echo form_open('admin_home/remove_users');?>
					   <div class="module">
                                <div class="module-head">
                                    <h3>
                                        Users List</h3>
                                </div>
                                <div class="module-body table">
                                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display"
                                        width="100%">
                                        <thead>
                                            <tr>
											 <th>
                                                 First Name
                                             </th>
                                             <th>
                                                  Last Name
                                             </th>
                                             <th>
                                                  Email
                                             </th>
                                             <th>
                                                 DOB
                                             </th>
                                         
                                              
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
										   <?php
												foreach($user_details as $row)
													{
														$first_name=$row['first_name'];
														$last_name=$row['last_name'];
														$email=$row['email'];
														$dob=$row['dob'];
														echo '
																<tr class="odd gradeA">
																	<td>'.$first_name.'</td>
																	<td>'.$last_name.'</td>
																	<td>'.$email.'</td>
																	<td class="center">'.$dob.'</td>
																</tr>
														';
													}
												?>
                                           
                                            

                                        <tfoot>
                                         <tr>
											 <th>
                                                 First Name
                                             </th>
                                             <th>
                                                  Last Name
                                             </th>
                                             <th>
                                                  Email
                                             </th>
                                             <th>
                                                 DOB
                                             </th>
                                         
                                         </tr>
                                        </tfoot>
                                    </table>
								</div>
								</div>
								 <div class="control-group" style="text-align:right;">
							
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
