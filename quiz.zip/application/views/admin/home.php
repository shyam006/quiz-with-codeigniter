
                    <div class="span9">
					<div class="content">
                            <div class="btn-controls">
                                <div class="btn-box-row row-fluid">
                                    <a href="#" class="btn-box big span4"><i class=" icon-dashboard"></i><b><?php echo $quiz_num; ?></b>
                                        <p class="text-muted">
                                            Quiz</p>
                                    </a><a href="#" class="btn-box big span4"><i class="icon-group"></i><b><?php echo $users_num; ?></b>
                                        <p class="text-muted">
                                            Users</p>
                                    </a><a href="#" class="btn-box big span4"><i class="icon-user"></i><b><?php echo $admin_num; ?></b>
                                        <p class="text-muted">
                                            Admin</p>
                                    </a>
                                </div>
                                                                  
                                </div>
                            </div>
                            <!--/#btn-controls-->
                           
                            
                            <div class="module">
                                <div class="module-head">
                                    <h3>
                                        Quiz List</h3>
                                </div>
                                <div class="module-body table">
                                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th>
                                                   Title
                                                </th>
                                                <th>
                                                    Duration
                                                </th>
                                                <th>
                                                    Created On
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                           <?php
												foreach ($quiz_list as $row)  
													{
													echo'<tr><td>'.$row['title'].'</td>
													<td>'.$row['duration'].'Mins</td>
													<td>'.$row['date'].'</td>
													
													</tr>';
													}
										   ?>
                                           

                                        <tfoot>
                                           <tr>
                                                <th>
                                                   Title
                                                </th>
                                                <th>
                                                    Duration
                                                </th>
                                                <th>
                                                    Created On
                                                </th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            <!--/.module-->
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
