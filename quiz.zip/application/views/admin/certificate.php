<?php
?>
                    <div class="span9">
                       <?php echo form_open('admin_home/remove_users');?>
					   <div class="module">
                                <div class="module-head">
                                    <h3>
                                        Users List</h3>
                                </div>
                                <div class="module-body table">
                                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display"
                                        width="100%">
                                        <thead>
                                            <tr>
											<th>
                                                  Name
                                             </th>
                                             <th>
                                                  Email
                                             </th>
                                             <th>
                                                 Quiz Title
                                             </th>
											 <th>
                                                 Percentage
                                             </th>
											 <th>
                                                 Completed On
                                             </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                           
                                           
                                            <tr class="odd gradeA">
												
                                                <td>
                                                    Trident
                                                </td>
                                                <td>
                                                    Internet Explorer 5.5
                                                </td>
                                                <td>
                                                    Win 95+
                                                </td>
												<td>
                                                    ABCD
                                                </td>
												<td>
                                                    <button type="button" class="btn btn-info">Edit</button> <button type="button" class="btn btn-danger">Delete</button>
                                                </td>
                                            </tr>

                                        <tfoot>
                                         <tr>
											 <th>
                                                  Name
                                             </th>
                                             <th>
                                                  Email
                                             </th>
                                             <th>
                                                 Quiz Title
                                             </th>
											 <th>
                                                 Percentage
                                             </th>
											 <th>
                                                 Completed On
                                             </th>
                                        </tr>
                                        </tfoot>
                                    </table>
								</div>
								</div>
								 
							<?php echo form_close();?>
                            
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
       
