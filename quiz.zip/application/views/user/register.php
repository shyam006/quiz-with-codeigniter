<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script> 

function load()
{

var email=document.getElementById('email');
var value = document.getElementById('email').value;
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
if(filter.test(value))
{

	$.ajax({type:"GET",url:'check_mail',data:{ email:value},
	
	success:function(response)
		{
		
			$("#email_status").html(response); 
			
		}
		
		});


}

else
{

document.getElementById('email_status').innerHTML="Enter a valid Email Id";
}

}
</script>
<br>
<br><br>
<div class="row container">
<div class="col-sm-6 mx-auto">
		<div class="text-center mx-auto" style="width:fit-content; margin:auto;">
				<img id="img" class="lazyOwl" alt="Lazy Owl Image" src="<?php echo base_url();?>assets/users/images/c3.jpg" style="display: block; border-radius:50%;">
		</div>
</div>
	<div class="col-sm-6">
	<?php 
	echo form_open_multipart('user/check_user');
	?>
		<div class="form-group">
			<input class="form-control" value="<?php echo set_value('email');?>" onkeyup="load();" id="email" type="email" name="email" placeholder="Enter your Email-ID*">
			<p style="color: red;" id="email_status"></p>
			<?php echo form_error('email','<p style="color:red">'); ?>
		</div>
		<div class="form-group">
			<input class="form-control" value="<?php echo set_value('first_name');?>"  type="text" name="first_name" placeholder="Enter your first_name*">
			<?php echo form_error('first_name','<p style="color:red">'); ?>
		</div>
		<div class="form-group">
			<input class="form-control" value="<?php echo set_value('last_name');?>"  type="text" name="last_name" placeholder="Enter your last_name">
		</div>
		<div class="form-group">
			<input class="form-control" value="<?php echo set_value('date');?>"  type="date" name="date" >
			<?php echo form_error('date','<p style="color:red">'); ?>
		</div>
			
		<div class="form-group">
			<input class="form-control"  type="password" name="password" placeholder="Enter your password*">
			<?php echo form_error('password','<p style="color:red">'); ?>
		</div>
		<div class="form-group">
			<input class="form-control"  type="password" name="conf_password" placeholder="Enter to Confirm password*">
			<?php echo form_error('conf_password','<p style="color:red">'); ?>
		</div>
		<div class="form-group text-center">
			<button type="submit" class="btn btn-success">Login</button>
		</div>
		<?php
		echo form_close();
		?>
		<div class="text-right" style="font-size: 14px;"><a href="<?php echo base_url('index.php/user/user_login'); ?>" class="btn">Already a user? |Login.</a></div>
	</div>
</div><br><br><br>

	<script>
 function imgfile(input) {
/*  alert(input); */
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
				
                    $('#img')
                        .attr('src', e.target.result)
                        .width(220)
                        .height(220)
						
					
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>

<div class="main_btm"><!-- start main_btm -->
	<div class="container">
		
				<!----start-img-cursual---->
					<div id="owl-demo" class="owl-carousel text-center">
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c1.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">vehicula diam</a></h4>
								<p>
									Lorem ipsum dolor amet,consectetur adipisicing elit, sed do eiusmod tempor incididunt dolore magna aliqua.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c2.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Morbi nunc</a></h4>
								<p>
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c3.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									On the other hand, we denounce with righteous indignation and dislike men who are so beguiled  pleasure of the moment,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c4.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Sed faucibus</a></h4>
								<p>
									Lorem ipsum dolor amet,consectetur adipisicing elit, sed do eiusmod tempor incididunt dolore magna aliqua.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c2.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c3.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									On the other hand, we denounce with righteous indignation and dislike men who are so beguiled  pleasure of the moment,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c4.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">vehicula diam</a></h4>
								<p>
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c1.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									On the other hand, we denounce with righteous indignation and dislike men who are so beguiled  pleasure of the moment,
								</p>
							</div>
						</div>
					</div>
					<!----//End-img-cursual---->
	</div>
</div>
