<?php
if($this->session->flashdata('done'))
{
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Learner a education bootstrap Website Template | Home :: w3layouts</title>
<!-- Bootstrap -->
<link href="<?php echo base_url();?>assets/users/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url();?>assets/users/css/bootstrap.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<link href="<?php echo base_url();?>assets/users/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- start plugins -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/bootstrap.min.js"></script>
<!-- start slider -->
<link href="<?php echo base_url();?>assets/users/css/slider.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/modernizr.custom.28468.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/jquery.cslider.js"></script>
	<script type="text/javascript">
			// $(function() {

				// $('#da-slider').cslider({
					// autoplay : true,
					// bgincrement : 450
				// });

			// });
		</script>
<!-- Owl Carousel Assets -->
<link href="<?php echo base_url();?>assets/users/css/owl.carousel.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/users/js/owl.carousel.js"></script>
		<script>
			// $(document).ready(function() {

				// $("#owl-demo").owlCarousel({
					// items : 4,
					// lazyLoad : true,
					// autoPlay : true,
					// navigation : true,
					// navigationText : ["", ""],
					// rewindNav : false,
					// scrollPerPage : false,
					// pagination : false,
					// paginationNumbers : false,
				// });

			// });
		</script>
		<!-- //Owl Carousel Assets -->
<!----font-Awesome----->
   	<link rel="stylesheet" href="<?php echo base_url();?>assets/users/fonts/css/font-awesome.min.css">
<!----font-Awesome----->
<style>

</style>
</head>
<body>
<div class="header_bg">
<div class="container">
	<div class="row header">
		<div class="logo navbar-left">
			<h1>Learner</h1>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<?php

foreach ($test as $row)
	{
		$id=$row['id'];
		$title=$row['title'];
		$users=$row['no_of_users'];
		$ques=$row['questions'];
		$type=$row['type'];
		$duration=$row['duration'];
		$options=$row['options'];
		$answer=$row['answers'];
		$test_id=$id;
		//decoding the string to array format//
		$ques=json_decode($ques);
		$type=json_decode($type);
		$options=json_decode($options);
		$answer=json_decode($answer);
		
	}
	
?>


<?php
$count=count($ques)*2;
if($id==$this->session->userdata('time_id'))
{
	if($this->session->userdata('min'))
	{
		$min=$this->session->userdata('min');
		$sec=$this->session->userdata('sec');
		$duration= $min .":". $sec;
		$x=$min*60;
		$y=$x+$sec;
		$z=$y/60;
		$count=$z;
	}
	
}

?>



<div class="container-fluid">
<div class="row top mx-auto" style="padding: 2px;position: sticky;top:0px;">
					<div class="col-sm-6">
						<h2><?php echo $title; ?></h2>
					</div>
					<div class="col-sm-6 text-right">
						<span id="time" style="font-size: 60px;"><?php echo $duration; ?></span><span> Minutes</span>
					</div>

					<script src="<?php echo base_url();?>assets/countdown-timer/countdown.js"></script>
					
				</div>
	
		<div class="row">
		<div class="col-md-2">
		</div>
		
		<div class="col-md-8">
		<?php echo form_open('quiz/quiz_validate'); ?>
			<div class="control-group">
				
				<input type="hidden" value="<?php echo $_REQUEST['id']; ?>" name="test_id">
				<input type="hidden" value="<?php echo $this->session->userdata('id') ; ?>" name="user_id">
				<input type="hidden" value="<?php echo count($ques) ; ?>" name="ques_count">
			</div>
			
			<br><br>
			<?php
			
					for($i=0;$i<count($ques);$i++)
					{
					
					$qno=$i+1;
						$ques_type=$type[$i];
						
						switch($ques_type)
							{
								case "single":
									{
										echo'<h3>'.$qno.'. '.$ques[$i].'</h3>';
										$id=0;
										foreach ($options[$i] as $row)
											{
												$id++;
												echo'
													<div class="control-group">
														<input type="radio" name="ques_'.$qno.'_ans[]" value="'.$row.'" id="'.$qno.$id.'"> 
														<label for="'.$qno.$id.'"><span><span></span></span>'.$row.'</label>
													</div>
													
												';
											}
										break;
									}
								case "multiple":
									{
										echo'<h3>'.$qno.'. '.$ques[$i].'</h3>';
										$id=0;
										foreach ($options[$i] as $row)
											{
												$id++;
												echo'
													<div class="control-group">
														<input type="checkbox" name="ques_'.$qno.'_ans[]" value="'.$row.'" id="'.$qno.$id.'"> 
														<label for="'.$qno.$id.'"><span><span></span></span>'.$row.'</label>
													</div>
													
												';
											}
										break;
									}
								case "boolean":
									{
										echo'<h3>'.$qno.'. '.$ques[$i].'</h3>';
										$id=0;
										foreach ($options[$i] as $row)
											{
												$id++;
												echo'
													<div class="control-group">
														<input type="radio" name="ques_'.$qno.'_ans[]" value="'.$row.'" id="'.$qno.$id.'"> 
														<label for="'.$qno.$id.'"><span><span></span></span>'.$row.'</label>
													</div>
													
												';
											}
										break;
									}
							}
							echo'<br>';
					}
			?>
			
		</div>
		
	</div>
	<div class="container">
	<div class="text-right">
		<button class="btn btn-info" id="submit">Submit</button>
	</div><br>
	<?php echo form_close(); ?>
	</div>
</div>


<style>

input[type=checkbox]{
  display: none;
}

.top{
	background-color:#3B3B3B;
	color:white;
	z-index:50;
}
input[type=checkbox] + label > span {
  display: inline-block;
  width: 15px;
  height: 15px;
  margin: 3px 6px 3px 3px;
  border: 1px solid #B3B6BD;
  border-radius: 3px;
  vertical-align: bottom;
}

input[type=checkbox]:checked + label > span > span {
  display: block;
  width: 7px;
  height: 7px;
  margin: 3px;
  border: 1px solid #E12BB7;
  border-radius: 2px;
  background: #E12BB7
;
}



input[type=radio]{
  display: none;
}

/* Style custom radio button shell */
input[type=radio] + label > span {
  display: inline-block;
  width: 15px;
  height: 15px;
  margin: 3px 6px 3px 3px;
  border: 1px solid #B3B6BD;
  border-radius: 8px;
  vertical-align: bottom;
}



/* If you want cursor change on hover */
 input[type=radio] + label > span:hover {
  cursor: pointer;
} 
 input[type=checkbox] + label > span:hover {
  cursor: pointer;
}

/* Style custom selected radio button bullet */
input[type=radio]:checked + label > span > span {
  display: block;
  width: 7px;
  height: 7px;
  margin: 3px;
  border: 1px solid #E12BB7;
  border-radius: 5px;
  background: #E12BB7
;
}

label {
  
  font-size: 15px;
  color: #363738;
}
</style>




<script>

window.onload = function () {

var tim=<?php echo $count;?>;
history.pushState(null, null, "/");
    var fiveMinutes = 60 * tim ,
        display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
	
};


function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        // minutes = minutes < 10 ? "0" + minutes : minutes;
        // seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds ;

        if (--timer < 0) {
			$( "#submit" ).trigger( "click" );	
          }
		  
		  var min= minutes;
		  var seconds= seconds ;		  
		$.ajax({
	url:'<?php echo base_url('quiz/timings');?>',
	type:'post',
	data:{min:min, sec:seconds, id:<?php echo $test_id; ?>},
	success: function(response){
	
	}});
		  
    }, 1000);
}




$('document').ready(function()
{

window.onbeforeunload = confirmExit;
    function confirmExit() {
		return "You have attempted to leave this page. Are you sure?";
    }
	



});
 



   



</script>
<script type="text/javascript">
function disableF5(e) { if ((e.which || e.keyCode) == 116 || (e.which || e.keyCode) == 82) e.preventDefault(); };

$(document).ready(function(){
     $(document).on("keydown", disableF5);
});



document.addEventListener('contextmenu', event => event.preventDefault());

  /*  window.onbeforeunload = function() {
         "Dude, are you sure you want to leave? Think of the kittens!";
    } */
	
	

/* function onBeforeUnloadAction()
{   
   
      var flag = confirm("close?");
        
    var mesg = "You have not entered all the required fields. "+ 
                      "If you exit this window without submitting this data, "+
                      "your request will be deleted from the system. "+ 
                      "Would you like to continue to exit this window?";
    
      if(!flag)
      {
          window.beforeunload = null;
       } else {
          return  mesg;
      }

}

window.onbeforeunload = onBeforeUnloadAction; */

</script>