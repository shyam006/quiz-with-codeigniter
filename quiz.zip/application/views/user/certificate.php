<?php
if($this->session->flashdata('done'))
{
$session=$this->session->flashdata('done');
unset($_SESSION['done']);
echo'<script>
window.opener.location = "'.base_url().'index.php/Logged_users/certificate";
	window.close();
</script>';
}
?>
<div class="container">
	<div class=" row form-group">
		
	
<?php

foreach($certificate as $row)
{
	echo '
				<div class="col-sm-6">
					<h3 style="margin-left:100px;">'.$row['title'].'</h3>
				</div>
				<div class="col-sm-6 text-center" style="padding:20px;">';
				if($row['min_percentage']<=$row['percentge'])
					{
						echo'<a href="'.base_url().'assets/certificates/'.$row['certificate'].'" download="My_Certificate"><button class="btn btn-info">Download</button> </a>';
					}
				else
					{
						echo'<h5 style="color:red">You have not cleared this Quiz </h5>';
					}
				
				echo'</div>';
	}

?>
	</div>
</div>

