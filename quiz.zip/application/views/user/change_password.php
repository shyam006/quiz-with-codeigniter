<br><br><br>
<div class="row container">
<div class="col-sm-6 mx-auto">
		<div class="text-center mx-auto" style="width:fit-content; margin:auto;">
				<img id="img" class="lazyOwl" alt="Lazy Owl Image" src="<?php echo base_url();?>assets/users/images/c3.jpg" style="display: block; border-radius:50%;">
		</div>
</div>
	<div class="col-sm-6">
	<?php 
	echo form_open_multipart('Logged_users/update_password');
	
		if($this->session->flashdata('password'))
		echo '<div style="text-align:center"><span style="color:green;font-size:14px;">'.$this->session->flashdata('password').'</span></div><br>';
	?>
		
		<div class="form-group">
			<input class="form-control"  type="password" name="old_password" placeholder="Enter your Old Password*">
			<?php echo form_error('old_password','<p style="color:red">'); ?>
		</div>
		<div class="form-group">
			<input class="form-control" type="password" name="new_password" placeholder="Enter your New Password*">
			<?php echo form_error('new_password','<p style="color:red">'); ?>
		</div>
		<div class="form-group">
			<input class="form-control" type="password" name="conf_password" placeholder="Enter your Conform Password*">
			<?php echo form_error('conf_password','<p style="color:red">'); ?>
		</div>
		
		<div class="form-group text-center">
			<button type="submit" class="btn btn-success">Update</button>
		</div>
		<?php
		echo form_close();
		?>
		
	</div>
</div>