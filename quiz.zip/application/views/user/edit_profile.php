<br><br><br>
<div class="row container">
<div class="col-sm-6 mx-auto">
		<div class="text-center mx-auto" style="width:fit-content; margin:auto;">
				<img id="img" class="lazyOwl" alt="Lazy Owl Image" src="<?php echo base_url();?>assets/users/images/c3.jpg" style="display: block; border-radius:50%;">
		</div>
</div>
	<div class="col-sm-6">
	<?php 
	echo form_open_multipart('Logged_users/update');
	foreach($user_details as $row)
		{
			$email=$row['email'];
			$first_name=$row['first_name'];
			$last_name=$row['last_name'];
			$dob=$row['dob'];
		}
		if($this->session->flashdata('updated'))
		echo '<div style="text-align:center"><span style="color:green;font-size:14px;">'.$this->session->flashdata('updated').'</span></div><br>';
	?>
		<div class="form-group">
			<input readonly class="form-control" value="<?php echo $email;?>" onkeyup="load();" id="email" type="email" name="email" placeholder="Enter your Email-ID*">
			<p style="color: red;" id="email_status"></p>
			<?php echo form_error('email','<p style="color:red">'); ?>
		</div>
		<div class="form-group">
			<input class="form-control" value="<?php echo $first_name;?>"  type="text" name="first_name" placeholder="Enter your first_name*">
			<?php echo form_error('first_name','<p style="color:red">'); ?>
		</div>
		<div class="form-group">
			<input class="form-control" value="<?php echo $last_name;?>"  type="text" name="last_name" placeholder="Enter your last_name">
		</div>
		<div class="form-group">
			<input class="form-control" value="<?php echo $dob;?>"  type="date" name="date" >
			<?php echo form_error('date','<p style="color:red">'); ?>
		</div>
		
		<div class="form-group text-center">
			<button type="submit" class="btn btn-success">Update</button>
		</div>
		<?php
		echo form_close();
		?>
		
	</div>
</div>