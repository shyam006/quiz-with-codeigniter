<?php
foreach ($user_details as $row)
	{
		$first=$row['first_name'];
		$last=$row['last_name'];
		$email=$row['email'];
		$id=$row['id'];
		$dob=$row['dob'];
	}
?>	
	<br><br>
	
	<div class="row container">
	<div style="text-align:right;">
		<a href='<?php echo base_url('index.php/Logged_users/edit_profile'); ?>'><button class="btn btn-info">Edit Profile</button></a>
		</div><br>
		<br>
<div class="col-sm-6 mx-auto">
		<div class="text-center mx-auto" style="width:fit-content; margin:auto;">
				<img id="img" class="lazyOwl" alt="Lazy Owl Image" src="<?php echo base_url();?>assets/users/images/c3.jpg" style="display: block; border-radius:50%;">
		</div>
</div>
	<div class="col-sm-6">
			<table class="table table-borderless" style="border:none; font-size: 14px;">
				<tr>
					<td>Name</td>
					<td><?php echo $first. $last;?></td>
				</tr>
				<tr>
					<td>Email ID</td>
					<td><?php echo $email;?></td>
				</tr>
				<tr>
					<td>Date of Birth</td>
					<td><?php echo $dob;?></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><a href='change_password'><button class="btn btn-sm btn-warning">Change Password</button></a></td>
				</tr>
				</table>
	</div>
</div><br><br><br>