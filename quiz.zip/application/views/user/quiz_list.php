

<br><br>
<div class="container">
<?php
if($this->session->flashdata('success'))
{
echo '
<div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  Success! <strong>'.$this->session->flashdata('success').'!</strong>
</div>
';
}
?>

	<div class="container">
		<?php
			foreach($test as $row)
				{
					$title=$row['title'];
					$id=$row['id'];
					$date=$row['date'];
					$users=$row['no_of_users'];
					$duration=$row['duration'];
					$date= date('M d, Y',strtotime($date));
					$anchr=base_url('logged_users/test_hall').'?id='.$id;
					
					echo'
						<h4>'.$title.'</h4>
				<a href="single-page.html"><img src="images/blog_pic1.jpg" alt="" class="blog_img img-responsive"></a>
				<div class="blog_list">
					  <ul class="list-unstyled">
						<li><i class="fa fa-calendar-o"></i><span>'.$date.'</span></li>
						<li><a href="#"><i class="fa fa-clock-o"></i><span>'.$duration.' mins</span></a></li>
				  		
				  	</ul>
				</div>
				<div class="read_more">
					<button data-a="'.$anchr.'" onclick="new_window(this)" class="fa-btn btn-1 btn-1e">Start Test</button>
				</div>
					';
				}
		?>
		<div class="col-md-8 blog_left">
				
				
			</div>
		

	</div>

</div>
<script>
var testhall=null;
window.onload=checkchild;
function checkchild()
{
	if(testhall && !testhall.closed)
	{
		alert();
	}

}
window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 4000);

function new_window(url)
{
var url=url.getAttribute('data-a');
        testhall=window.open(url,"_blank","toolbar=no,scrollbars=yes,resizable=no,top=0,left=0,width=2000,height=950");
		
}

</script>