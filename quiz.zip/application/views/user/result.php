<?php
	
	$user_id=$answers['user_id'];
	$test_id=trim($answers['test_id']);
	/* echo $test_id; */
	$user_answers=$answers['user_answers'];
	$user_answers=json_decode($user_answers);
	$right_answer=$this->test->get_test_hall($test_id);
	foreach($right_answer as $row)
			{
				$questions=$row['questions'];
				$questions=json_decode($questions);
			}
?>			
<div class="container">	
	<div class="container">
		
		<?php	
		
		for($i=0;$i<count($correct_answer);$i++)
		{
			$qno=$i+1;
			echo '<h3>'.$qno.'- '.$questions[$i].'</h3>';
			if($correct_answer[$i]==$user_answers[$i])
			{
				echo '<div class="container"><h5><span style="color:green">';
				foreach ($correct_answer[$i] as $rows1)
				{
					echo '<span style="color:green">'.$rows1.'<br>';
				}
				echo '</span></h5></div>';
			}
			else
			{
			if($user_answers[$i])
			{
				echo '<div class="container"><h5> Your answer is :<span style="color:red"> ';
				foreach ($user_answers[$i] as $rows2)
				{
				echo '<br>'.$rows2.'</span></h5></div>';
				}
			}
				echo'<div class="container"><h5>The correct answer is :';
				foreach ($correct_answer[$i] as $rows1)
				{
					echo '<br><span style="color:green">'.$rows1;
				}
				echo '</span></h5></div>';
			
			}
			
			
		}
		
?>
<br>
<br>
<h3>MARK LIST</h3><span class="bg-info" style="border-radius: 4px;padding: 3px;">you can collect your Certificate in Certificate tab</span>
		<table class="table" style="font-size:14px;">
			<thead>
			<th>Total Mark</th>
			<th>Obtained</th>
			<th>Percentage</th>
			</thead>
			<tr>
			<td><?php echo count($questions)?></td>
			<td><?php echo $answers['correct_answers'] ?></td>
			<td><?php echo $answers['percentge'] ?></td>
			</tr>
		</table>
		<div id="certificate_details" class="text-center">
		</div>
		
		<div class="container text-center">
		<button class="btn btn-success" id="close">Close</button></a>
		</div>
	</div>
</div>
<br><br>
<?php


$user_name=$this->session->userdata('first_name').$this->session->userdata('last_name');
$percentage1=$answers['percentge'];
$file_name=$this->session->userdata('id').$test_id;
$destin='assets/certificates/'.$file_name.'.png';

$path=base_url().'assets/admin/certificates/certificate.jpg';
$im = imagecreatefromjpeg($path);
$name=imagecreate(200,50);
$bg=imagecolorallocate($name,255,255,255);
$color=imagecolorallocate($name,0,0,0);
imagestring($name,5,5,20,$user_name,$color);//------Name--------//


$percentage=imagecreate(50,50);
$bg=imagecolorallocate($percentage,255,255,255);
$color=imagecolorallocate($name,0,0,0);
imagestring($percentage,5,5,15,$percentage1,$color); //------Percentage--------//

imagecopymerge($im, $name, 195,130 , 0, 0, 200,50, 100);
imagecopymerge($im, $percentage, 240,270 , 0, 0, 40,40, 100);

// Save the image to file and free memory
imagepng($im, $destin);//------Name of the file (user_id + test_id--------//
/* echo $img;exit; */
imagedestroy($im);
$f_name = $file_name.'.png';
echo '<input type="text" value="'.$f_name.'" id="certificate" hidden>';
$this->session->flashdata('success','');
?>
	
	<script>
	
	$('document').ready(function(){
	var cert_name = $('#certificate').val();
	var res_id=<?php echo $id; ?>;
	
	if(cert_name != "")
	{
		$.ajax({
		type:"GET",
		url:'<?php echo base_url().'quiz/save_certificate';?>',
		data:{
		c_name :cert_name,id :res_id
		},success:function(response)
		{
			$("#certificate_details").html(response);
		}

		});
		
		$.ajax({
		type:"GET",
		url:'<?php echo base_url().'quiz/mail_certificate';?>',
		data:{
		c_name :cert_name
		},success:function(response)
		{
			
		}

		});
	
	
	
		
	}
	
	});
	
	$('#close').click(function(){
	opener.location.href = '<?php echo base_url('Logged_users/quiz');?>';
	close();
	});
		
function disableF5(e) { if ((e.which || e.keyCode) == 116 || (e.which || e.keyCode) == 82) e.preventDefault(); };

$(document).ready(function(){
     $(document).on("keydown", disableF5);
});
window.onload = function () {
history.pushState(null, null, "/");
}


document.addEventListener('contextmenu', event => event.preventDefault());
	</script>
