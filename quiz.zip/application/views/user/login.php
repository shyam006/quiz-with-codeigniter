<br><br><br>
<div class="row container">
<div class="col-sm-6 mx-auto">
		<div class="text-center mx-auto" style="width:fit-content; margin:auto;">
				<img class="lazyOwl" alt="Lazy Owl Image" src="<?php echo base_url();?>assets/users/images/c3.jpg" style="display: block;">
		</div>
</div>
	<div class="col-sm-6">
	<?php 
	echo form_open('user/check_login');
		if($this->session->flashdata('error'))
		{
		echo '<div class="text-center"><span style="color: red;font-size: 12px;">'.$this->session->flashdata('error').'</span></div><br>';
		}
	?>
		<div class="form-group">
			<input class="form-control"  type="email" name="email" placeholder="Enter your Email-ID">
		</div>
		<div class="form-group">
			<input class="form-control"  type="password" name="password" placeholder="Enter your password">
		</div>
		<div class="form-group text-center">
			<button type="submit" class="btn btn-success">Login</button>
		</div>
		<?php
		echo form_close();
		?>
		<div class="text-right" style="font-size: 14px;"><a href="<?php echo base_url('index.php/user/user_register');?>" class="btn">Register Here..!</a></div>
	</div>
</div><br><br><br>
<div class="main_btm"><!-- start main_btm -->
	<div class="container">
		
				<!----start-img-cursual---->
					<div id="owl-demo" class="owl-carousel text-center">
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c1.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">vehicula diam</a></h4>
								<p>
									Lorem ipsum dolor amet,consectetur adipisicing elit, sed do eiusmod tempor incididunt dolore magna aliqua.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c2.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Morbi nunc</a></h4>
								<p>
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c3.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									On the other hand, we denounce with righteous indignation and dislike men who are so beguiled  pleasure of the moment,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c4.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Sed faucibus</a></h4>
								<p>
									Lorem ipsum dolor amet,consectetur adipisicing elit, sed do eiusmod tempor incididunt dolore magna aliqua.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c2.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c3.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									On the other hand, we denounce with righteous indignation and dislike men who are so beguiled  pleasure of the moment,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c4.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">vehicula diam</a></h4>
								<p>
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<img class="lazyOwl" data-src="<?php echo base_url();?>assets/users/images/c1.jpg" alt="Lazy Owl Image">
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									On the other hand, we denounce with righteous indignation and dislike men who are so beguiled  pleasure of the moment,
								</p>
							</div>
						</div>
					</div>
					<!----//End-img-cursual---->
	</div>
</div>
