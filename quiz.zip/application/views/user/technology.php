
</div>
<div class="main_bg"><!-- start main -->
	<div class="container">
		<div class="technology row">
			<h2>our technologies</h2>
			<div class="technology_list">
				<h4>1. There are many variations of passages of Lorem Ipsum available?</h4>
				<div class="col-md-10 tech_para">
					<p class="para">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				</div>
				<div class="col-md-2 images_1_of_4 bg1 pull-right">
					<span class="bg"><i class="fa fa-files-o"></i> </span>
				</div>
				<div class="clearfix"></div>
				<div class="read_more">
					<a href="single-page.html" class="fa-btn btn-1 btn-1e">read more</a>
				</div>	
			</div>
			<div class="technology_list1">
				<h4>2. Lorem Ipsum is simply dummy text of the printing and typesetting industry?</h4>
				<div class="col-md-10 tech_para">
					<p class="para">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				</div>
				<div class="col-md-2 images_1_of_4 bg1">
					<span class="bg"><i class="fa fa-laptop"></i> </span>
				</div>
				<div class="clearfix"></div>
				<div class="read_more">
					<a href="single-page.html" class="fa-btn btn-1 btn-1e">read more</a>
				</div>	
			</div>
			<div class="technology_list1">
				<h4>3. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium?</h4>
				<div class="col-md-10 tech_para">
					<p class="para">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				</div>
				<div class="col-md-2 images_1_of_4 bg1">
					<span class="bg"><i class="fa fa-cog"></i></span>
				</div>
				<div class="clearfix"></div>
				<div class="read_more">
					<a href="single-page.html" class="fa-btn btn-1 btn-1e">read more</a>
				</div>	
			</div>
			<div class="technology_list1">
				<h4>4. There are many variations of passages of Lorem Ipsum available ?</h4>
				<div class="col-md-10 tech_para">
					<p class="para">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				</div>
				<div class="col-md-2 images_1_of_4 bg1">
					<span class="bg"><i class="fa fa-files-o"></i> </span>
				</div>
				<div class="clearfix"></div>
				<div class="read_more">
					<a href="single-page.html" class="fa-btn btn-1 btn-1e">read more</a>
				</div>	
			</div>
			<ul class="pagination">
			  <li><a href="#">&laquo;</a></li>
			  <li><a href="#">1</a></li>
			  <li><a href="#">2</a></li>
			  <li><a href="#">3</a></li>
			  <li><a href="#">4</a></li>
			  <li><a href="#">5</a></li>
			  <li><a href="#">&raquo;</a></li>
			</ul>
			<div class="alert alert-warning alert-dismissable">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <strong>Warning!</strong> Better check yourself, you're not looking too good.
			</div>
		</div>
	</div>
</div><!-- end main -->
