<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Learner a education bootstrap Website Template | Home :: w3layouts</title>
<!-- Bootstrap -->
<link href="<?php echo base_url();?>assets/users/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url();?>assets/users/css/bootstrap.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<link href="<?php echo base_url();?>assets/users/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- start plugins -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/bootstrap.min.js"></script>
<!-- start slider -->
<link href="<?php echo base_url();?>assets/users/css/slider.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/modernizr.custom.28468.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/users/js/jquery.cslider.js"></script>
	<script type="text/javascript">
			// $(function() {

				// $('#da-slider').cslider({
					// autoplay : true,
					// bgincrement : 450
				// });

			// });
		</script>
<!-- Owl Carousel Assets -->
<link href="<?php echo base_url();?>assets/users/css/owl.carousel.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/users/js/owl.carousel.js"></script>
		<script>
			// $(document).ready(function() {

				// $("#owl-demo").owlCarousel({
					// items : 4,
					// lazyLoad : true,
					// autoPlay : true,
					// navigation : true,
					// navigationText : ["", ""],
					// rewindNav : false,
					// scrollPerPage : false,
					// pagination : false,
					// paginationNumbers : false,
				// });

			// });
		</script>
		<!-- //Owl Carousel Assets -->
<!----font-Awesome----->
   	<link rel="stylesheet" href="<?php echo base_url();?>assets/users/fonts/css/font-awesome.min.css">
<!----font-Awesome----->
<style>

</style>
</head>
<body>
<div class="header_bg">
<div class="container">
	<div class="row header">
		<div class="logo navbar-left">
			<h1><a href="index.html">Learner </a></h1>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
</div>
<div class="container">
	<div class="row h_menu">
		<nav class="navbar navbar-default navbar-left" role="navigation">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		    </div>
		    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      <ul class="nav navbar-nav">
		        <li class=""><a href="<?php echo base_url('user/user_home');?>">Home</a></li>
		        <li><a href="<?php echo base_url('user/user_technology');?>">Technologies</a></li>
		        <li><a href="<?php echo base_url('user/user_about');?>">About</a></li>
		        <li><a href="<?php echo base_url('user/user_blog');?>">Blog</a></li>
		        <li><a href="<?php echo base_url('user/user_contact');?>">Contact</a></li>
				 
				 <?php
					if($this->session->userdata('email'))
					{
						echo '<li><a href="'.base_url('user/user_logout').'" >Logout </a></li>
						';
					}
					else
					{
					echo'<li><a href="'.base_url('user/user_login').'">Login</a></li>';
					}
				 ?>
		      </ul>
		    </div><!-- /.navbar-collapse -->
		    <!-- start soc_icons -->
		</nav>
		
	</div>
</div>