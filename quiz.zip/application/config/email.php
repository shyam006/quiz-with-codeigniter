<?php
	$config['protocol']  = 'smtp';
	$config['smtp_host'] = 'smtp.openwavecomp.in';
	$config['smtp_port'] = 25;
	$config['smtp_timeout'] = 30;
	$config['smtp_user'] = 'admin@openwavecomp.in';
	$config['smtp_pass'] = 'Sterling#2010';
	$config['mailtype']  = 'html';
	$config['charset']  = 'utf-8';
	$config['wordwrap']  = TRUE;
	$config['newline']  = '\r\n';
	
?>