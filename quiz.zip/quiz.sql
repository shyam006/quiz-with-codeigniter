-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2018 at 05:42 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `first_name`, `last_name`, `user_name`, `email`, `password`) VALUES
(21, 'Admin', 'istrator', 'Admin', 'admin@123.com', '0e7517141fb53f21ee439b355b5a1d0a'),
(22, 'Shyam', 'Sundar', 'AdminShyam', 'sundarshyam006@gmail.com', 'b2ec2d95c293a49e8b69b60a4ceb9a9f');

-- --------------------------------------------------------

--
-- Table structure for table `demo`
--

CREATE TABLE `demo` (
  `id` int(5) NOT NULL,
  `emai` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `test_id` int(5) NOT NULL,
  `user_answers` varchar(21844) NOT NULL,
  `correct_answers` int(5) NOT NULL,
  `percentge` float NOT NULL,
  `certificate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `user_id`, `test_id`, `user_answers`, `correct_answers`, `percentge`, `certificate`) VALUES
(12, 7, 9, '[["qwerty"]]', 1, 100, '79.png'),
(13, 7, 11, '[]', 0, 0, '711.png'),
(14, 7, 12, '[]', 0, 0, '712.png'),
(15, 7, 19, '[["Biro Brothers"],["1950s"],["Rubber boot"],["Marie Curie"],["1900"],["Giuseppe Mercalli"],["Thermometer"],["Alexander Hamilton"],["Steam boat"],["Norfolk"],["Gottlieb Daimler"],["Parachute"],["Sir Frank Whittle"],["There is no sure date"],["1880s"]]', 5, 33.33, '719.png'),
(16, 7, 20, '[["True"],["False"],["True"],["True"],["True"],["True"]]', 5, 83.33, '720.png'),
(17, 7, 5, '[["one "],["multiple-1","multiple-4"],["True"]]', 3, 100, '75.png'),
(18, 7, 6, '[["Playing Games","Reading Books"],["3"],["True"],["20"],["100"]]', 4, 80, '76.png'),
(19, 7, 10, '[["5"],["0+4"],null,null,null]', 1, 20, '710.png'),
(20, 7, 17, '[null,null,null,null,null]', 0, 0, '717.png');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(5) NOT NULL,
  `title` varchar(255) NOT NULL,
  `questions` varchar(21844) NOT NULL,
  `type` varchar(255) NOT NULL,
  `options` varchar(21844) NOT NULL,
  `answers` varchar(10000) NOT NULL,
  `date` date NOT NULL,
  `duration` int(11) NOT NULL,
  `no_of_users` int(5) NOT NULL,
  `min_percentage` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `title`, `questions`, `type`, `options`, `answers`, `date`, `duration`, `no_of_users`, `min_percentage`) VALUES
(5, 'Test-1', '["select one","select multiple","select true"]', '["single","multiple","single"]', '[["one ","two","three"],["multiple-1","multiple-2","multiple-3","multiple-4"],["True","False"]]', '[["one "],["multiple-1","multiple-4"],["True"]]', '2018-08-31', 6, 100, 40),
(6, 'Test-2', '["hobies","Sum of 1+2","2+3=5?","10+10=?","10*10=?"]', '["multiple","single","single","single","single"]', '[["Playing Games","Listen Music","Reading Books"],["5","9","3"],["True","False"],["10","20","100"],["100","1000","10"]]', '[["Playing Games","Reading Books"],["3"],["False"],["20"],["100"]]', '2018-08-31', 10, 60, 40),
(9, 'test-3', '["hai"]', '["single"]', '[["qwerty","asdhdg","asdffgjh"]]', '[["qwerty"]]', '2018-09-03', 2, 10, 40),
(10, 'Maths', '["2+3=?","?+?=4","1+1=2?","2*2=?","1\\/1=?"]', '["single","multiple","single","single","single"]', '[["5","6","6"],["2+2","4+0","0+4","4+1"],["True","False"],["4","5","6"],["1","0","2"]]', '[["5"],["2+2","4+0","0+4"],["True"],["4"],["1"]]', '2018-09-05', 10, 40, 50),
(15, 'General Science - Elements and Metals', '["Brass gets discoloured in air because of the presence of which of the following gases in air?","Which of the following is a non metal that remains liquid at room temperature?","Chlorophyll is a naturally occurring chelate compound in which central metal is","Which of the following is used in pencils?","Which of the following metals forms an amalgam with other metals?","Chemical formula for water is","The gas usually filled in the electric bulb is","Washing soda is the common name for","Quartz crystals normally used in quartz clocks etc. is chemically","Which of the gas is not known as green house gas?"]', '["single","single","single","single","single","single","single","single","single","single"]', '[["Oxygen","Hydrogen sulphide","Carbon dioxide","Nitrogen"],["Phosphorous","Bromine","Chlorine","Helium"],["copper","magnesium","iron","calcium"],["Graphite","Silicon","Charcoal","Phosphorous"],["Tin","Mercury","Lead","Zinc"],["NaAlO2","H2O","Al2O3","CaSiO3"],["nitrogen","hydrogen","carbon dioxide","oxygen"],["Sodium carbonate","Calcium bicarbonate","Sodium bicarbonate","Calcium carbonate"],["silicon dioxide","germanium oxide","a mixture of germanium oxide and silicon dioxide","sodium silicate"],["Methane","Nitrous oxide","Carbon dioxide","Hydrogen"]]', '[["Hydrogen sulphide"],["Bromine"],["magnesium"],["Silicon"],["Mercury"],["H2O"],["nitrogen"],["Sodium carbonate"],["silicon dioxide"],["Hydrogen"]]', '2018-09-10', 20, 20, 40),
(17, 'Introduction to Database', '["Which of the following products implemented the CODASYL DBTG model?","An Enterprise Resource Planning application is an example of a(n) ________ .","A DBMS that combines a DBMS and an application generator is ________ .","You have run an SQL statement that asked the DBMS to display data in a table named USER_TABLES. The results include columns of data labeled \\"TableName,\\" \\"NumberOfColumns\\" and \\"PrimaryKey.\\" You are looking at ________ .","Which of the following is not considered to be a basic element of an enterprise-class database system?"]', '["single","single","single","single","single"]', '[["IDMS","DB2","dBase-II","R:base"],["single-user database application","multiuser database application","e-commerce database application","data mining database application"],["Microsoft''s SQL Server","Microsoft''s Access","IBM''s DB2","Oracle Corporation''s Oracle"],["user data.","metadata","A report","indexes"],["Users","Database applications","DBMS","COBOL programs"]]', '[["IDMS"],["multiuser database application"],["Microsoft''s Access"],["metadata"],["COBOL programs"]]', '2018-09-10', 10, 3, 40),
(19, 'Inventions', '["Who invented the BALLPOINT PEN?","\\t\\r\\nIn which decade was the first solid state integrated circuit demonstrated?","What J. B. Dunlop invented?","Which scientist discovered the radioactive element radium?","When was barb wire patented?","What is the name of the CalTech seismologist who invented the scale used to measure the magnitude of earthquakes?","What Galileo invented?","\\t\\r\\nThis statesman, politican, scholar, inventor, and one of early presidents of USA invented the swivel chair, the spherical sundial, the moldboard plow, and the cipher wheel.","What James Watt invented?","Who invented Jet Engine?","Who invented Jet Engine?","What invention caused many deaths while testing it?","Who invented Gunpowder?","Until Victorian times, chocolate was thought of as a drink. When did the first chocolate bar appear?","In which decade was the telephone invented?"]', '["single","single","single","single","single","single","single","single","single","single","single","single","single","single","single"]', '[["Biro Brothers","Waterman Brothers","Bicc Brothers","Write Brothers"],["1950s","1960s","1970s","1980s"],["Pneumatic rubber tire","Automobile wheel rim","Rubber boot","Model airplanes"],["Isaac Newton","Albert Einstein","Benjamin Franklin","Marie Curie"],["1874","1840","1895","1900"],["Charles Richter","Hiram Walker","Giuseppe Mercalli","Joshua Rumble"],["Barometer","Pendulum clock","Microscope","Thermometer"],["George Washington","Alexander Hamilton","John Adams","Thomas Jefferson"],["Diving bell","Steam boat","Hot air balloon","Rotary steam engine"],["Yorkshire","Lancashire","Staffordshire","Norfolk"],["Sir Frank Whittle","Gottlieb Daimler","Roger Bacon","Lewis E. Waterman"],["Dynamite","Ladders","Race cars","Parachute"],["G. Ferdinand Von Zeppelin","Sir Frank Whittle","Roger Bacon","Leo H Baekeland"],["1828","1831","1825","There is no sure date"],["1850s","1860s","1870s","1880s"]]', '[["Biro Brothers"],["1950s"],["Pneumatic rubber tire"],["Marie Curie"],["1874"],["Charles Richter"],["Thermometer"],["Thomas Jefferson"],["Rotary steam engine"],["Yorkshire"],["Sir Frank Whittle"],["Parachute"],["Roger Bacon"],["1828"],["1870s"]]', '2018-09-10', 30, 3, 40),
(20, 'Maths-1', '["2+2=4","3*5=20","1\\/0=infinity","1\\/1=1","10\\/5=2","20-10=10"]', '["single","single","single","single","single","single"]', '[["True","False"],["True","False"],["True","False"],["True","False"],["True","False"],["True","False"]]', '[["True"],["False"],["True"],["True"],["True"],["False"]]', '2018-09-12', 12, 2, 40);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile` varchar(255) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `first_name`, `last_name`, `email`, `password`, `profile`, `dob`) VALUES
(3, 'Shyam', 'Sundar', 'sundarshyam006@gmail.com', 'b2ec2d95c293a49e8b69b60a4ceb9a9f', '', '1995-06-18'),
(4, 'User', 'User.com', 'user@user.com', '9eeaf04ead83d91063237f9e99d4caee', '', '0001-01-01'),
(5, 'Sidharth', '', 'sidharth007@gmail.com', '6896acd96fc8653de3db18aea82425eb', '', '1993-08-07'),
(6, 'Shyam', 'Sundar', 'student@123.com', '9e16c1f8ec5aaf14a0a2b73a9903ddb2', '', '1995-06-18'),
(7, 'Admin', 'Istrator', 'admin@123.com', '0e7517141fb53f21ee439b355b5a1d0a', '', '1998-12-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- Indexes for table `demo`
--
ALTER TABLE `demo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emai` (`emai`),
  ADD UNIQUE KEY `emai_2` (`emai`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
